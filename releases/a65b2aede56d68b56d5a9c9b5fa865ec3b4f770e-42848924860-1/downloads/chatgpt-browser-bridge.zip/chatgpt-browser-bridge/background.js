import {createBridgeService} from './service.js';

const api = globalThis.browser || globalThis.chrome;
const STORAGE_KEY = 'chatgpt-browser-bridge-v1';
const ALARM = 'chatgpt-browser-bridge-pump';
let timer;
let pumping;
let wakeRequested = false;
const service = createBridgeService({
  load: async () => (await api.storage.local.get(STORAGE_KEY))[STORAGE_KEY],
  save: state => api.storage.local.set({[STORAGE_KEY]: state}),
  tabs: api.tabs,
  page: async (tabId, action, data) => {
    try { return await api.tabs.sendMessage(tabId, {target: 'chatgpt-bridge-content', action, ...data}); }
    catch { throw Object.assign(new Error('The dedicated ChatGPT tab could not be reached. Open it to check sign-in or browser verification.'), {code: 'PAGE_UNREACHABLE'}); }
  },
});

function wake() {
  if (pumping) { wakeRequested = true; return pumping; }
  clearTimeout(timer);
  pumping = service.pump().then(async outcome => {
    if (!outcome.active) { await api.alarms.clear(ALARM); return; }
    const nextAt = Math.max(Date.now() + 100, outcome.nextAt || Date.now());
    // Alarms survive suspended workers; a short timer gives responsive progress while awake.
    await api.alarms.create(ALARM, {when: nextAt, periodInMinutes: 1});
    if (nextAt - Date.now() < 25_000) timer = setTimeout(wake, Math.max(100, nextAt - Date.now()));
  }).catch(() => {
    // Durable state remains available; retry storage/page recovery without sending again.
    void api.alarms.create(ALARM, {delayInMinutes: 1});
  }).finally(() => {
    pumping = null;
    if (wakeRequested) { wakeRequested = false; void wake(); }
  });
  return pumping;
}
api.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.target !== 'browser-bridge-service') return false;
  service.dispatch(message, sender).then(result => { respond(result); void wake(); }, error => {
    respond({ok: false, error: {code: 'BRIDGE_ERROR', message: error.message}});
  });
  return true;
});
api.alarms.onAlarm.addListener(alarm => { if (alarm.name === ALARM) void wake(); });
api.runtime.onStartup.addListener(() => { void wake(); });
api.runtime.onInstalled.addListener(() => { void wake(); });
void wake();

api.tabs.onRemoved?.addListener(tabId => {
  void service.cancelOwnerTab(tabId).then(wake).catch(() => {});
});
api.tabs.onUpdated?.addListener((tabId, change) => {
  if (change.status === 'loading') void service.cancelOwnerTab(tabId).then(wake).catch(() => {});
});
