// Chrome serializes this function into the isolated world of the run's top-level document.
// The private snapshot keeps DOM references here. Neither the model nor the app supplies selectors.
export async function jobPageOperation(action, request) {
  let clicked = false;
  try {
    if (window !== window.top || location.href !== request.url) throw new Error('The employer page changed. Read it again.');
    const state = globalThis.__cvJobPage ||= { ids: new WeakMap(), writes: new WeakMap(), sequence: 0 };
    const clean = value => String(value || '').replace(/\s+/g, ' ').trim();
    function idFor(node, prefix) {
      if (!state.ids.has(node)) state.ids.set(node, prefix + ++state.sequence);
      return state.ids.get(node);
    }
    const visibility = new WeakMap();
    function visible(el) {
      if (!el) return false;
      if (visibility.has(el)) return visibility.get(el);
      const style = getComputedStyle(el);
      const shown = !el.matches('[hidden],[inert],[aria-hidden="true"]') && style.display !== 'none'
        && style.visibility !== 'hidden' && (!el.parentElement || visible(el.parentElement));
      visibility.set(el, shown);
      return shown;
    }
    function labelText(node) {
      if (!node) return '';
      const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
      const words = [];
      while (walker.nextNode()) {
        if (!walker.currentNode.parentElement?.closest('input,select,textarea,option,button,script,style,svg,[contenteditable=true]'))
          words.push(walker.currentNode.textContent);
      }
      return clean(words.join(' '));
    }
    const enabled = el => !el.matches(':disabled,[aria-disabled="true"]') && !el.closest('[inert]');
    function controlLabel(el) {
      return clean(el.getAttribute('aria-label') || (el.tagName === 'INPUT' ? el.value : el.textContent));
    }
    const finalLabel = /^(?:submit(?: (?:my |your |job |this )?application)?|send (?:my |your |job |this )?application|complete (?:my |your |this )?application)$/i;
    const applyLabel = /^apply(?: now| here| online| (?:for|to) (?:this |the )?(?:role|job|position))?$/i;
    const nextLabel = /^(?:next(?: step)?|continue(?: to (?:next step|review))?|review application)$/i;
    const buttons = 'button,a[href],input[type=button],input[type=submit],[role=button]';
    const formCandidates = [...document.querySelectorAll('form,[role=form]')].filter(form => {
      if (!visible(form)) return false;
      return /(?:application|apply)(?:\b|[-_])/i.test([form.id, form.className, form.getAttribute('aria-label')].join(' '))
        || [...form.querySelectorAll(buttons)].some(el => /(?:submit|send|complete).*application/i.test(controlLabel(el)))
        || [...form.querySelectorAll('input[type=file]')].some(el => /resume|résumé|curriculum|\bcv\b/i.test([el.id, el.name, el.labels?.[0]?.textContent].join(' ')));
    });
    const scope = formCandidates.length === 1 ? formCandidates[0] : null;
    const inputSelector = 'input,textarea,select,[role=combobox],[role=checkbox],[role=radio],[contenteditable=true]';
    function materialField(info) {
      if (/\b(?:transcript|certificate|portfolio|reference|passport|licen[cs]e|sample|proof|permit)s?\b/i.test(info.label)) return false;
      const letter = /\bcover(?:ing)?[\s-]*letter\b|\bmotivation(?:al)? letter\b|\bletter of (?:application|motivation)\b/i.test(info.label);
      const resume = /\bcv\b|\bcurriculum vitae\b|\br[eé]sum[eé](?![\p{L}\p{N}])/iu.test(info.label);
      return (info.kind === 'file' && (letter || resume)) || (info.kind === 'textarea' && letter);
    }
    const materialValue = node => node.type === 'file' ? node.files?.[0] : node.value;
    function choices(el) {
      if (!el.name || !['radio','checkbox'].includes(el.type)) return [];
      return [...scope.querySelectorAll('input')].filter(other => other.type === el.type && other.name === el.name && enabled(other) && visible(other));
    }
    function observedValue(node, info) {
      if (node.type === 'radio' && info.kind === 'select') return choices(node).find(peer => peer.checked);
      if (node.type === 'checkbox' || node.type === 'radio') return node.checked;
      if (node.tagName === 'SELECT') return node.selectedIndex;
      return materialValue(node);
    }
    function descriptor(el) {
      if (!scope || !(scope.contains(el) || el.form === scope) || !enabled(el)
        || ['hidden','button','submit','reset','image'].includes(el.type) || el.readOnly) return null;
      const question = el.closest('.application-question');
      const upload = el.closest('.file-upload');
      if (!(visible(el) || (el.type === 'file' && !el.closest('[inert]') && visible(upload || question || el.labels?.[0])))) return null;
      const group = clean((question?.querySelector('.application-label') || el.closest('fieldset')?.querySelector('legend'))?.textContent);
      const labelledBy = (el.getAttribute('aria-labelledby') || '').split(/\s+/).map(id => document.getElementById(id)?.textContent || '').join(' ');
      const marked = clean(labelText(upload?.querySelector('.upload-label')) || group || labelText(el.labels?.[0]));
      const named = clean(el.getAttribute('aria-label') || labelledBy || labelText(el.labels?.[0]));
      const isChoice = ['radio','checkbox'].includes(el.type);
      const separateChoice = isChoice && named && named !== group;
      let label = clean(separateChoice && group ? group + ' — ' + named : (marked || named || el.placeholder || el.name || el.id));
      if (el.tagName === 'TEXTAREA' && el.placeholder && !label.includes(el.placeholder)) label += ' (' + el.placeholder + ')';
      label = label.slice(0, 1200);
      let kind = el.tagName === 'TEXTAREA' ? 'textarea' : el.tagName === 'SELECT' ? 'select' : el.type;
      const combobox = el.matches('[role=combobox]') && el.tagName !== 'SELECT';
      const locationSelection = el.parentElement?.querySelector('input[type=hidden][name=selectedLocation]');
      if (combobox || locationSelection || !['text','email','tel','url','number','date','textarea','select','radio','checkbox','file'].includes(kind) || el.multiple)
        kind = 'unsupported';
      let required = !!el.required || el.getAttribute('aria-required') === 'true'
        || /[✱*]\s*$/.test(marked) || el.closest('.required-field') !== null;
      let filled = !!clean(el.value);
      let options, groupInfo;
      if (kind === 'select') {
        options = [...el.options].filter(o => !o.disabled && o.value).map(o => clean(o.textContent));
        filled = !!el.selectedOptions[0]?.value;
      } else if (isChoice) {
        const peers = choices(el);
        if (el.type === 'radio' && peers.length > 1) {
          if (peers[0] !== el) return null;
          kind = 'select';
          const labelOf = peer => clean(peer.labels?.[0]?.textContent || peer.value);
          label = group || named || el.name;
          options = peers.map(labelOf);
          required ||= peers.some(peer => peer.required);
          filled = peers.some(peer => peer.checked);
        } else {
          filled = el.checked;
          // Label-marked checkbox groups require any one choice. Native individually
          // required checkboxes retain their own validity regardless of their peers.
          if (el.type === 'checkbox' && peers.length > 1 && !el.required && required)
            required = el === peers[0] && !peers.some(peer => peer.checked);
          if (el.type === 'checkbox' && peers.length > 1) groupInfo = {
            groupId: 'g' + idFor(peers[0],'f'), groupLabel: group || el.name,
            groupRequired: !el.required && (/[✱*]\s*$/.test(marked) || !!el.closest('.required-field')),
          };
        }
      } else if (kind === 'file') filled = !!el.files?.length;
      else if (combobox) filled = !!clean(el.closest('.select__container')?.querySelector('.select__single-value,.select__multi-value')?.textContent);
      else if (locationSelection) filled = !!clean(locationSelection.value);
      const valid = (!el.validity || el.validity.valid) && el.getAttribute('aria-invalid') !== 'true' && (!required || filled);
      const receipt = state.writes.get(el);
      const written = !!receipt && receipt.value === materialValue(el);
      return { id: idFor(el, 'f'), kind, label, required, filled, valid, written, ...groupInfo,
        ...(written && receipt.version ? { materialVersion: receipt.version } : {}),
        ...(kind === 'file' ? { accept: el.accept || '' } : {}),
        ...(options ? { options } : {}), ...(el.maxLength > 0 ? { maxLength: el.maxLength } : {}) };
    }
    function actionInfo(el) {
      if (!visible(el) || !enabled(el)) return null;
      const label = controlLabel(el);
      const form = el.form || el.closest('form,[role=form]');
      const inScope = scope && (scope.contains(el) || scope === form);
      let kind;
      if (inScope && (finalLabel.test(label) || (el.type === 'submit' && applyLabel.test(label)))) kind = 'submit';
      else if (inScope && nextLabel.test(label)) kind = 'next';
      else if (!form && applyLabel.test(label) && !el.hasAttribute('download')
        && (scope || el.matches('a[href]:not([href="#"])') || document.getElementById(el.getAttribute('aria-controls')))) kind = 'apply';
      if (!kind || (form && form !== scope)) return null;
      return { id: idFor(el,'a'), kind, label };
    }
    function getControls() {
      const fields = new Map(), actions = new Map(), blockers = [];
      if (formCandidates.length > 1) blockers.push('Multiple application forms are visible.');
      if (scope) {
        const native = scope.elements ? [...scope.elements] : [];
        for (const node of new Set([...scope.querySelectorAll(inputSelector), ...native])) {
          if (!node.matches(inputSelector)) continue;
          const info = descriptor(node);
          if (info) fields.set(info.id, { node, info, original: observedValue(node, info) });
        }
      }
      for (const node of document.querySelectorAll(buttons)) {
        const info = actionInfo(node);
        if (info) actions.set(info.id, { node, info, href: node.href || '', formAction: node.formAction || node.form?.action || '' });
      }
      if ([...document.querySelectorAll('iframe')].some(el => visible(el) && !el.closest('nav,footer') &&
        /captcha|challenge|turnstile|application|apply|greenhouse|lever\.co/i.test([el.title,el.src,el.name].join(' '))))
        blockers.push('An embedded application or verification challenge needs attention on the employer page.');
      if ([...document.querySelectorAll('input[type=password]')].some(visible)) blockers.push('The employer page asks you to sign in.');
      if (scope && [...scope.querySelectorAll('[role=alert],.field-error,.application-error')].some(el => visible(el) && clean(el.textContent)))
        blockers.push('The application form shows a validation message.');
      if (scope && [...scope.querySelectorAll('[role=progressbar],[aria-busy=true],.uploading,.resume-loading')].some(visible))
        blockers.push('The employer is still processing a field or an attachment.');
      if (fields.size > 160) blockers.push('This application contains too many controls to check automatically.');
      return { fields, actions, blockers };
    }
    function readBlocks() {
      const root = document.querySelector('main') || document.body;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      const groups = new Map();
      let size = 0;
      while (walker.nextNode() && size < 60000 && groups.size < 450) {
        const text = clean(walker.currentNode.textContent);
        const parent = walker.currentNode.parentElement;
        if (!text || !parent || parent.closest('script,style,template,noscript,svg,nav,footer,button,input,select,textarea,label,[contenteditable=true]')) continue;
        if (parent.closest('form,[role=form]') && !(scope?.contains(parent) &&
          parent.closest('h1,h2,h3,h4,h5,h6,.field-help,.help-text,.instructions,[data-instructions]'))) continue;
        const block = parent.closest('p,li,h1,h2,h3,h4,h5,h6,blockquote,section,article,div') || parent;
        if (!visible(parent)) continue;
        const prior = groups.get(block) || '';
        groups.set(block, clean(prior + ' ' + text).slice(0, 5000));
        size += text.length;
      }
      return [...groups].map(([node, text]) => ({
        id: idFor(node, 'b'), text, tag: node.tagName.toLowerCase(),
        ...(node.closest('.job__description,.job-post-content,[itemprop=description],[data-qa=job-description],.posting-page .section') && !node.closest('form,[role=form]') ? { scope: 'listing' } : {}),
        ...(node.closest('.field-help,.help-text,.instructions,[data-instructions]') ? { scope: 'instruction' } : {}),
      }));
    }
    const current = getControls();
    if (action === 'read') {
      const id = crypto.randomUUID();
      const blocks = readBlocks();
      state.snapshot = { id, url: location.href, ...current, scope, blocks, title: document.title };
      const confirmed = blocks.some(block => /^(?:thank you for applying\b|thank you for (?:submitting )?your application\b|(?:we(?:'ve| have) received|we received) your application\b|your application (?:has been|was) (?:successfully )?(?:submitted|received)\b|application (?:successfully )?(?:submitted|received)[.!]?$)/i.test(block.text));
      return { ok: true, value: { id, title: document.title, url: location.href, blocks,
        fields: [...current.fields.values()].slice(0,160).map(f => f.info),
        actions: [...current.actions.values()].map(a => a.info), blockers: current.blockers, confirmed } };
    }
    const saved = state.snapshot;
    if (!saved || saved.id !== request.snapshotId || saved.url !== location.href || saved.scope !== scope)
      throw new Error('The application page changed. Read it again.');
    const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
    if (document.title !== saved.title || !same(saved.blocks, readBlocks()))
      throw new Error('The posting changed since it was checked. Read the employer page again.');
    function checked(map, id) {
      const was = saved[map].get(id), now = current[map].get(id);
      if (!was || !now || was.node !== now.node || !same(was.info, now.info) || was.original !== now.original ||
        was.href !== now.href || was.formAction !== now.formAction)
        throw new Error('A control changed since this page was read. Inspect the page again.');
      return now;
    }
    function prepare(entry) {
      const { node, info } = checked('fields', entry.id);
      if (info.kind === 'unsupported' || !info.label) throw new Error('This employer field needs manual entry.');
      if (info.filled && !materialField(info)) throw new Error('A field already has a value. Inspect the employer page before replacing it.');
      if (entry.materialVersion !== undefined && (!materialField(info) || typeof entry.materialVersion !== 'string' || entry.materialVersion.length > 100))
        throw new Error('Unexpected document version for this field.');
      if (info.kind === 'file') {
        const file = entry.file;
        if (!file || !/^[^/\\\x00-\x1F]{1,150}\.pdf$/i.test(file.name) || typeof file.data !== 'string' || file.data.length > 20e6 || !file.data.startsWith('JVBERi0'))
          throw new Error('Upload a generated PDF with a valid filename.');
        if (node.accept && !node.accept.split(',').some(type => ['.pdf','application/pdf','application/*','*/*'].includes(type.trim().toLowerCase())))
          throw new Error('This field does not accept PDF files.');
        const bytes = Uint8Array.from(atob(file.data), c => c.charCodeAt(0));
        const transfer = new DataTransfer();
        transfer.items.add(new File([bytes], file.name, { type: 'application/pdf' }));
        return () => {
          node.files = transfer.files;
          if (node.files.length !== 1 || node.files[0].name !== file.name || node.files[0].size !== bytes.length)
            throw new Error('The employer file field did not accept the generated PDF.');
        };
      }
      if (info.kind === 'radio' || info.kind === 'checkbox') {
        if (typeof entry.value !== 'boolean') throw new Error('Select an explicit checkbox or radio value.');
        return () => { if (node.checked !== entry.value) node.click(); };
      }
      if (typeof entry.value !== 'string' || !entry.value.trim() || entry.value.length > (info.maxLength || 100000))
        throw new Error('The answer is empty or exceeds the field limit.');
      let value = entry.value;
      if (info.kind === 'select') {
        if (!info.options.includes(value)) throw new Error('The choice is absent from the observed options.');
        if (node.type === 'radio') {
          const matches = choices(node).filter(peer => clean(peer.labels?.[0]?.textContent || peer.value) === value);
          if (matches.length !== 1) throw new Error('This radio choice is ambiguous.');
          return () => matches[0].click();
        }
        const matches = [...node.options].filter(o => !o.disabled && clean(o.textContent) === value);
        if (matches.length !== 1) throw new Error('This selection is ambiguous.');
        value = matches[0].value;
      }
      const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(node), 'value')?.set;
      if (!setter) throw new Error('This field needs manual entry.');
      return () => setter.call(node, value);
    }
    if (action === 'fill') {
      if (!Array.isArray(request.entries) || request.entries.length === 0 || request.entries.length > 160 ||
        new Set(request.entries.map(entry => entry.id)).size !== request.entries.length)
        throw new Error('Expected a list of distinct fields.');
      const changes = request.entries.map(entry => ({ field: checked('fields',entry.id), write: prepare(entry) }));
      state.snapshot = null;
      for (const { field, write } of changes) {
        if (location.href !== request.url || !field.node.isConnected || !same(field.info, descriptor(field.node)))
          throw new Error('The form changed while filling. Read the page to see which fields were accepted.');
        write();
        if (!['checkbox','radio'].includes(field.node.type)) {
          field.node.dispatchEvent(new Event('input', { bubbles: true }));
          field.node.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }
      // Let controlled inputs process the input/change events and read their values back
      // locally. Sending typed values or uploaded filenames to the model is unnecessary.
      await new Promise(resolve => setTimeout(resolve, 120));
      for (let i = 0; i < changes.length; i++) {
        const { node, info } = changes[i].field, entry = request.entries[i];
        let accepted;
        if (info.kind === 'file') {
          const file = node.files?.[0];
          accepted = node.isConnected && file?.name === entry.file.name && file.size === Math.floor(entry.file.data.replace(/=+$/, '').length * 3 / 4);
          if (!accepted) accepted = !!scope && [...scope.querySelectorAll('.file-upload,.application-question.resume,[data-uploaded-file]')]
            .some(el => visible(el) && clean(el.textContent).includes(entry.file.name));
        } else if (info.kind === 'select' && node.type === 'radio') {
          const peer = choices(node).find(el => el.checked);
          accepted = node.isConnected && clean(peer?.labels?.[0]?.textContent || peer?.value) === entry.value;
        } else if (info.kind === 'select') accepted = node.isConnected && clean(node.selectedOptions[0]?.textContent) === entry.value;
        else if (['checkbox','radio'].includes(info.kind)) accepted = node.isConnected && node.checked === entry.value;
        else accepted = node.isConnected && node.value === entry.value;
        if (!accepted) throw new Error('The employer did not retain “' + info.label + '”. Check that field before continuing.');
        if (materialField(info)) state.writes.set(node, { value: materialValue(node), version: entry.materialVersion });
      }
      return { ok: true, value: { ok: true } };
    }
    const { node, info, href } = checked('actions', request.actionId);
    if (action === 'submit' ? info.kind !== 'submit' : action !== 'click' || info.kind === 'submit')
      throw new Error('This action does not match the observed control.');
    if (current.blockers.length) throw new Error(current.blockers.join(' '));
    if (info.kind !== 'apply') {
      const fields = [...current.fields.values()];
      const checkedReview = info.kind === 'submit' && request.verifiedPriorStep === true;
      if (!scope || (!fields.length && !checkedReview) || fields.some(f => !f.info.valid || (f.info.required && !f.info.filled)))
        throw new Error('Complete and validate the required application fields first.');
      if (scope.checkValidity && !scope.checkValidity()) throw new Error('The employer form contains an invalid field.');
      if (fields.length !== saved.fields.size || fields.some(f => {
        const before = saved.fields.get(f.info.id);
        return !before || before.node !== f.node || before.original !== f.original || !same(before.info, f.info);
      }))
        throw new Error('The form changed since it was checked.');
      const target = node.getAttribute('formtarget') || scope.getAttribute('target');
      const dest = node.getAttribute('formaction') || scope.getAttribute('action') || location.href;
      if ((target && target !== '_self') || new URL(dest,location.href).origin !== location.origin)
        throw new Error('This form sends the application to a different destination. Continue on the employer page.');
    }
    state.snapshot = null;
    if (node.tagName === 'A' && href && new URL(href,location.href).href.split('#')[0] !== location.href.split('#')[0]) {
      if (info.kind !== 'apply') throw new Error('This action opens a different page. Continue on the employer page.');
      return { ok: true, value: { navigate: href } };
    }
    clicked = true;
    node.click();
    return { ok: true, value: { ok: true } };
  } catch (failure) {
    return { ok: false, beforeClick: !clicked, error: failure?.message || 'Unable to operate on this employer page.' };
  }
}
