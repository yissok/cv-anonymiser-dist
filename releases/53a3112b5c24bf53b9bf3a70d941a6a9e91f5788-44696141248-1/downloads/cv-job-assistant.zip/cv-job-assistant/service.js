import { jobPageOperation } from './page.js';

const trustedAts = ['greenhouse.io','lever.co','ashbyhq.com','myworkdayjobs.com','smartrecruiters.com','workable.com','icims.com','jobs.personio.de','jobs.personio.com'];
const isAts = host => trustedAts.some(domain => host === domain || host.endsWith('.' + domain));
export function jobUrl(value) {
  const url = new URL(value);
  const host = url.hostname;
  if (url.protocol !== 'https:' || url.username || url.password || url.port || !host.includes('.') || host.endsWith('.') ||
    /^(?:\d+\.){3}\d+$/.test(host) || /[:\[\]]/.test(host) || /\.(?:local|localhost|internal|lan|test|invalid)$/.test(host))
    throw new Error('Enter a public HTTPS URL for the employer’s posting.');
  return url;
}
function trustedApp(value) {
  const url = new URL(value);
  const localApp = url.protocol === 'http:' && ['localhost','127.0.0.1'].includes(url.hostname)
    && ['4173','5173','5174'].includes(url.port)
    && ['/', '/cv-anonymiser/', '/cv-anonymiser-dist/'].includes(url.pathname);
  return localApp
    || (url.origin === 'https://scout-38aa2.web.app' && url.pathname.startsWith('/cv-anonymiser/'))
    || (url.origin === 'https://yissok.github.io' && url.pathname.startsWith('/cv-anonymiser-dist/'));
}
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

export function createJobService({ tabs, scripting, session, extensionId, sleep = wait }) {
  // Serialize each run, including the durable pre-click submission claim. A repeated or
  // concurrently delivered request must never click Submit again after an ambiguous result.
  const queues = new Map();
  const key = id => 'job-run-' + id;
  const persist = run => session.set({ [key(run.id)]: run });
  const success = value => ({ ok: true, value });
  function allowed(run, url) {
    if (url.origin === run.origin) return true;
    return !isAts(url.hostname) && url.hostname.replace(/^www\./,'') === new URL(run.origin).hostname.replace(/^www\./,'');
  }
  async function loadedTab(run) {
    for (let i = 0; i < 45; i++) {
      const tab = await tabs.get(run.tab);
      if (tab.url && tab.status !== 'loading' && !tab.pendingUrl) return tab;
      await sleep(300);
    }
    throw new Error('The employer page is still loading. Inspect it again when it is ready.');
  }
  async function dispatch(action, input, sender) {
    if (action === 'ping') return { available: true };
    if (action === 'open') {
      const url = jobUrl(input.url);
      // Lever's application-only route omits the posting. Start at the same job's
      // canonical description, which links to the actual application form.
      if (['jobs.lever.co','jobs.eu.lever.co'].includes(url.hostname)
        && /^\/[^/]+\/[\da-f]{8}-(?:[\da-f]{4}-){3}[\da-f]{12}\/apply\/?$/i.test(url.pathname))
        url.pathname = url.pathname.replace(/\/apply\/?$/, '');
      const tab = await tabs.create({ url: url.href, active: false });
      const id = crypto.randomUUID();
      const app = new URL(sender.url);
      await persist({ id, owner: sender.tab.id, ownerPage: app.origin + app.pathname,
        tab: tab.id, origin: url.origin, initial: true, snapshot: null, submitted: false });
      return { runId: id };
    }
    if (typeof input.runId !== 'string' || input.runId.length > 80) throw new Error('Unknown application run.');
    const run = (await session.get(key(input.runId)))[key(input.runId)];
    const app = new URL(sender.url);
    if (!run) throw Object.assign(new Error('This application run has ended.'), { code: 'RUN_ENDED' });
    if (run.owner !== sender.tab.id || run.ownerPage !== app.origin + app.pathname)
      throw new Error('This application run belongs to a different CV app tab.');
    if (action === 'end') {
      await session.remove(key(run.id));
      return { ok: true };
    }
    if (action === 'focus') {
      await tabs.update(run.tab, { active: true });
      return { ok: true };
    }
    if (run.submitted && action !== 'read') throw new Error('A submission was already attempted. Check the employer tab for its result.');
    const tab = await loadedTab(run);
    const url = jobUrl(tab.url);
    if (!allowed(run,url)) {
      // Allow one redirect to a known recruiting provider immediately after opening
      // the supplied listing or following its observed Apply action.
      if (!(action === 'read' && (run.initial || run.followApply) && isAts(url.hostname)))
        throw new Error('The employer tab moved to an unrecognised destination. Continue on the employer page.');
    }
    if (action !== 'read' && (!run.snapshot || input.snapshotId !== run.snapshot.id || url.href !== run.snapshot.url))
      throw new Error('This view is out of date. Read the employer page again.');
    const target = action === 'read' ? { tabId: run.tab, frameIds: [0] } : { tabId: run.tab, documentIds: [run.snapshot.document] };
    if (action === 'submit') {
      // Persist before injection. A tab navigation or lost response can otherwise replay the click.
      run.submitted = true;
      run.priorConfirmation = !!run.snapshot.confirmationVisible;
      await persist(run);
    }
    const [injected] = await scripting.executeScript({ target, func: jobPageOperation,
      args: [action, { ...input, url: url.href, verifiedPriorStep: run.verifiedPriorStep === true }] });
    if (!injected?.result?.ok) {
      // A returned rejection from the isolated-world validator preceded the click.
      // Lost/unknown responses keep the claim, so they can only be inspected manually.
      if (action === 'submit' && injected?.result?.ok === false && injected.result.beforeClick === true) {
        run.submitted = false;
        await persist(run);
      }
      throw Object.assign(new Error(injected?.result?.error || 'The page changed before the result could be checked. Inspect the employer tab.'),
        action === 'submit' && injected?.result?.beforeClick === true ? { code: 'SUBMIT_REJECTED' } : {});
    }
    const value = injected.result.value;
    if (action === 'read') {
      if (run.snapshot && !run.followApply && !run.followNext && !run.submitted && run.snapshot.url !== url.href)
        throw new Error('The employer tab moved to a different page. Start again with the intended posting.');
      run.origin = url.origin;
      run.initial = false; run.followApply = false; run.followNext = false;
      run.snapshot = { id: value.id, document: injected.documentId, url: url.href,
        actions: Object.fromEntries(value.actions.map(a => [a.id,a.kind])), confirmationVisible: value.confirmed };
      value.confirmed = (!run.submitted || !run.priorConfirmation) && value.confirmed;
      value.verifiedPriorStep = run.verifiedPriorStep === true;
      await persist(run);
      return value;
    }
    if (action === 'click') {
      const kind = run.snapshot.actions[input.actionId];
      run.followApply = kind === 'apply';
      run.followNext = kind === 'next';
      if (kind === 'next') run.verifiedPriorStep = true;
      if (kind === 'apply') run.verifiedPriorStep = false;
      if (value.navigate) {
        const destination = jobUrl(value.navigate);
        if (!allowed(run,destination) && !isAts(destination.hostname)) throw new Error('This Apply link leaves the employer for an unrecognised site. Open it manually.');
        await tabs.update(run.tab, { url: destination.href });
        run.origin = destination.origin;
      }
    }
    await persist(run);
    return { ok: true };
  }
  async function handle(message, sender) {
    try {
      if (sender?.id !== extensionId || sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) || !sender.documentId || !trustedApp(sender.url))
        throw new Error('Job Assistant requests must come from the CV app.');
      if (message?.version !== 1 || !['ping','open','read','fill','click','submit','end','focus'].includes(message.action))
        throw new Error('Unknown Job Assistant request.');
      const input = message.payload || {};
      const queueKey = input.runId || sender.documentId;
      const previous = queues.get(queueKey) || Promise.resolve();
      const next = previous.catch(() => {}).then(() => dispatch(message.action, input, sender));
      queues.set(queueKey, next);
      try { return success(await next); }
      finally { if (queues.get(queueKey) === next) queues.delete(queueKey); }
    } catch (failure) {
      return { ok: false, error: failure?.message || 'Job Assistant request failed.', code: failure?.code };
    }
  }
  async function forgetTab(tabId) {
    const data = await session.get(null);
    const keys = Object.keys(data).filter(k => k.startsWith('job-run-') && (data[k].owner === tabId || data[k].tab === tabId));
    if (keys.length) await session.remove(keys);
  }
  return { handle, forgetTab };
}
