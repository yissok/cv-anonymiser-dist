import { createJobService } from './service.js';

const service = createJobService({
  tabs: chrome.tabs, scripting: chrome.scripting, session: chrome.storage.session, extensionId: chrome.runtime.id,
});
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.channel !== 'cv-job-assistant') return false;
  void service.handle(message,sender).then(respond);
  return true;
});
chrome.tabs.onRemoved.addListener(tabId => void service.forgetTab(tabId));
