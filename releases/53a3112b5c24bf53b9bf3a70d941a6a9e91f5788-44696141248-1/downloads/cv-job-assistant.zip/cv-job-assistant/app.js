(() => {
  if (window.top !== window || window.__cvJobAssistant) return;
  window.__cvJobAssistant = true;
  const channel = 'cv-job-assistant';
  window.addEventListener('message', async event => {
    const message = event.data;
    if (event.source !== window || event.origin !== location.origin || message?.channel !== channel
      || message.direction !== 'request' || message.version !== 1 || !/^[\w-]{1,80}$/.test(message.id || '')) return;
    let response;
    try {
      response = await chrome.runtime.sendMessage({ channel, version: 1, action: message.action, payload: message.payload });
    } catch {
      response = { ok: false, error: 'Reload the CV app after updating the Job Assistant extension.' };
    }
    window.postMessage({ channel, direction: 'response', version: 1, id: message.id, ...response }, location.origin);
  });
})();
