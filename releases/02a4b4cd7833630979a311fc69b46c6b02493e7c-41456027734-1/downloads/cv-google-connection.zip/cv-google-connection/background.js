import { createGoogleExtensionService } from './service.js';
import { createWebIdentity } from './web-identity.js';
import { WEB_CLIENT_ID } from './config.js';

const webFlow = !!navigator.brave;
const manifest = chrome.runtime.getManifest();
const identity = webFlow ? createWebIdentity({ identity: chrome.identity, session: chrome.storage.session, clientId: WEB_CLIENT_ID }) : chrome.identity;

const service = createGoogleExtensionService({
  identity, storage: chrome.storage.local,
  manifest: webFlow ? { ...manifest, oauth2: { client_id: WEB_CLIENT_ID } } : manifest, extensionId: chrome.runtime.id,
});
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.target !== 'cv-google-extension') return false;
  void service.dispatch(message, sender).then(respond);
  return true;
});
