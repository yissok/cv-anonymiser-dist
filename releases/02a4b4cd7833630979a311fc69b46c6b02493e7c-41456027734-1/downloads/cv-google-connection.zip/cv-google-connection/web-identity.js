const failure = message => Object.assign(new Error(message), { code: 'auth-required' });

/** Brave's supported web flow. Never open a renewal window without a click. */
export function createWebIdentity({ identity, session, clientId, now = Date.now, cryptoImpl = crypto }) {
  const key = 'cv-google-web-token-v1';
  let generation = 0;
  async function getAuthToken({ interactive, scopes }) {
    const attempt = generation;
    const saved = (await session.get(key))[key];
    if (saved?.clientId === clientId && saved.expiresAt > now() && typeof saved.token === 'string' && scopes.every(scope => saved.grantedScopes?.includes(scope))) return saved;
    const redirect = identity.getRedirectURL();
    const state = cryptoImpl.randomUUID();
    const url = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    url.search = new URLSearchParams({
      client_id: clientId, redirect_uri: redirect, response_type: 'token',
      scope: scopes.join(' '), state, login_hint: 'andrea.lissak@gmail.com',
      prompt: interactive ? 'consent' : 'none', include_granted_scopes: 'false',
    });
    let callback;
    try {
      callback = await identity.launchWebAuthFlow({ url: url.href, interactive,
        ...(!interactive ? { abortOnLoadForNonInteractive: false, timeoutMsForNonInteractive: 15000 } : {}),
      });
    } catch { throw failure('Google needs your attention. Click Connect with extension to sign in again.'); }
    if (attempt !== generation) throw failure('Google sign-in was cancelled.');
    let result;
    try { result = new URL(callback); } catch { throw failure('Google did not return a valid sign-in response.'); }
    const expected = new URL(redirect);
    const values = new URLSearchParams(result.hash.slice(1));
    if (result.origin !== expected.origin || result.pathname !== expected.pathname || result.search || values.get('state') !== state) throw failure('Google sign-in could not be validated. Try again.');
    if (values.has('error')) throw failure('Google needs your attention. Click Connect with extension to continue.');
    const lifetime = Number(values.get('expires_in')) * 1000;
    const token = values.get('access_token');
    const grantedScopes = (values.get('scope') || '').split(' ');
    if (!token || token.length > 8192 || values.get('token_type')?.toLowerCase() !== 'bearer' || !Number.isFinite(lifetime) || lifetime <= 0 || !scopes.every(scope => grantedScopes.includes(scope))) throw failure('Google did not grant the required access. Reconnect and allow both permissions.');
    const value = { token, grantedScopes, clientId, expiresAt: now() + lifetime - Math.min(30000, lifetime / 10) };
    // Session storage survives worker suspension, but is never synced or exposed
    // to content scripts. Google refresh credentials are never requested.
    await session.set({ [key]: value });
    if (attempt !== generation) { await session.remove(key); throw failure('Google sign-in was cancelled.'); }
    return value;
  }
  async function removeCachedAuthToken({ token }) {
    const saved = (await session.get(key))[key];
    if (saved?.token === token) await session.remove(key);
  }
  async function clearAllCachedAuthTokens() { ++generation; await session.remove(key); }
  return { getAuthToken, removeCachedAuthToken, clearAllCachedAuthTokens };
}
