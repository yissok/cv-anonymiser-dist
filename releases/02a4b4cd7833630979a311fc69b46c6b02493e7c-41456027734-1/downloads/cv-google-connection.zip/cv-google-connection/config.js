// Public web OAuth client. Its extension HTTPS redirect must be allowlisted.
export const WEB_CLIENT_ID = '404244741287-91ji1m1cj0iv9psu1d3c5ngt8eoog5ij.apps.googleusercontent.com';
