export const SCOPES = ['https://www.googleapis.com/auth/drive.file', 'https://www.googleapis.com/auth/userinfo.email'];
const ENABLED_KEY = 'cv-google-enabled-v1';
const error = (code, message) => Object.assign(new Error(message), { code });

export function trustedPage(address) {
  try {
    const url = new URL(address);
    return (url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname))
      || (url.origin === 'https://scout-38aa2.web.app' && url.pathname.startsWith('/cv-anonymiser/'))
      || (url.origin === 'https://yissok.github.io' && url.pathname.startsWith('/cv-anonymiser-dist/'));
  } catch { return false; }
}

/** Only the CV app can request short-lived tokens from the browser adapter. */
export function createGoogleExtensionService({ identity, storage, manifest, extensionId, fetchImpl = fetch, now = Date.now }) {
  const clientId = manifest.oauth2?.client_id || '';
  const configured = /^\d+-[\w-]+\.apps\.googleusercontent\.com$/.test(clientId);
  const appId = clientId.split('-')[0];
  let generation = 0;
  let verified;
  let pending;

  async function token(interactive) {
    if (!configured) throw error('configuration', 'Set up the CV Google extension’s Chrome OAuth client first.');
    if (!identity?.getAuthToken) throw error('unavailable', 'Google access is unavailable in this browser.');
    if (pending) {
      try { return await pending; }
      catch (failure) { if (!interactive) throw failure; }
    }
    const attempt = generation;
    const operation = (async () => {
      if (!interactive && !(await storage.get(ENABLED_KEY))[ENABLED_KEY]) throw error('auth-required', 'Connect Google once to trust this Chrome profile.');
      let result;
      try { result = await identity.getAuthToken({ interactive, scopes: SCOPES, enableGranularPermissions: true }); }
      catch { throw error('auth-required', 'Google needs your attention. Click Connect with extension to continue.'); }
      const accessToken = result?.token;
      if (typeof accessToken !== 'string' || !accessToken || accessToken.length > 8192 || !SCOPES.every(scope => result.grantedScopes?.includes(scope))) {
        if (accessToken) await identity.removeCachedAuthToken({ token: accessToken });
        throw error('unauthorized', 'Allow selected-file access and your email address to connect Google.');
      }
      if (!verified || verified.token !== accessToken || verified.until <= now()) {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 20000);
        try {
          const response = await fetchImpl('https://www.googleapis.com/oauth2/v3/userinfo', {
            headers: { Authorization: `Bearer ${accessToken}` }, signal: controller.signal,
            credentials: 'omit', cache: 'no-store', redirect: 'error',
          });
          if (!response.ok) {
            if (response.status === 401) await identity.removeCachedAuthToken({ token: accessToken });
            throw error(response.status === 401 ? 'auth-required' : 'unavailable', 'Google could not verify access. Try connecting again.');
          }
          const account = await response.json();
          if (account.email_verified !== true || account.email?.toLowerCase() !== 'andrea.lissak@gmail.com') {
            await identity.removeCachedAuthToken({ token: accessToken });
            throw error('wrong-account', 'Use andrea.lissak@gmail.com in this browser profile.');
          }
          if (attempt !== generation) throw error('cancelled', 'Google sign-in was cancelled.');
          verified = { token: accessToken, email: account.email, until: now() + 60000 };
        } finally { clearTimeout(timeout); }
      }
      if (attempt !== generation) throw error('cancelled', 'Google sign-in was cancelled.');
      if (interactive) {
        await storage.set({ [ENABLED_KEY]: true });
        if (attempt !== generation) { await storage.set({ [ENABLED_KEY]: false }); throw error('cancelled', 'Google sign-in was cancelled.'); }
      }
      return { accessToken, email: verified.email, emailVerified: true, clientId, appId, scopes: SCOPES };
    })();
    pending = operation;
    try { return await operation; }
    finally { if (pending === operation) pending = null; }
  }

  async function dispatch(message, sender) {
    if (sender?.id !== extensionId || sender.frameId !== 0 || !Number.isInteger(sender.tab?.id) || !trustedPage(sender.url)) {
      return { ok: false, error: { code: 'forbidden', message: 'Google access is limited to the CV app’s main page.' } };
    }
    try {
      if (message?.version !== 1) throw error('invalid', 'Unsupported extension request.');
      let value;
      switch (message.action) {
        case 'status':
          value = { configured, clientId, appId, supported: !!identity?.getAuthToken };
          break;
        case 'token': value = await token(false); break;
        case 'connect': value = await token(true); break;
        case 'invalidate': {
          const stale = message.payload?.token;
          if (typeof stale !== 'string' || !stale || stale.length > 8192) throw error('invalid', 'Invalid token replacement request.');
          verified = null;
          await identity.removeCachedAuthToken({ token: stale });
          value = true;
          break;
        }
        case 'disconnect':
          ++generation;
          verified = null;
          await storage.set({ [ENABLED_KEY]: false });
          await identity.clearAllCachedAuthTokens();
          value = true;
          break;
        default: throw error('invalid', 'Unknown extension request.');
      }
      return { ok: true, value };
    } catch (failure) {
      return { ok: false, error: { code: failure.code || 'unavailable', message: failure.code ? failure.message : 'The Google extension could not complete this request. Try again.' } };
    }
  }
  return { dispatch };
}
