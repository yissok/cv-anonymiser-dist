(() => {
  const channel = 'cv-google-extension';
  if (window.top !== window || window.__cvGoogleExtension) return;
  window.__cvGoogleExtension = true;
  window.addEventListener('message', async event => {
    const request = event.data;
    if (event.source !== window || event.origin !== location.origin || request?.channel !== channel || request.direction !== 'request' || request.version !== 1) return;
    if (typeof request.id !== 'string' || !/^[\w-]{1,100}$/.test(request.id) || !['status', 'token', 'connect', 'invalidate', 'disconnect'].includes(request.action)) return;
    let result;
    try {
      result = await chrome.runtime.sendMessage({ target: channel, version: 1, action: request.action, payload: request.payload });
    } catch {
      result = { ok: false, error: { code: 'unavailable', message: 'Reload the CV app after updating its Google extension.' } };
    }
    window.postMessage({ channel, direction: 'response', version: 1, id: request.id, ...result }, location.origin);
  });
})();
