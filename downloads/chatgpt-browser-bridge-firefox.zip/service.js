export const PROTOCOL_VERSION = 1;
export const MAX_PROMPT_LENGTH = 2_200_000;
export const TERMINAL_STATES = new Set(['complete', 'error', 'cancelled', 'needs_attention']);
const STATES = new Set(['queued', 'checking', 'submitting', 'waiting', 'cooldown', ...TERMINAL_STATES]);
const COOLDOWNS = [5, 10, 20, 40, 60].map(minutes => minutes * 60_000);
const clone = value => JSON.parse(JSON.stringify(value));
const problem = (code, message) => Object.assign(new Error(message), {code});

export function ownerFor(sender) {
  if (!Number.isInteger(sender?.tab?.id) || (sender.frameId !== undefined && sender.frameId !== 0)) throw problem('FORBIDDEN', 'Only an allowed top-level application can use this bridge.');
  let url;
  try { url = new URL(sender.url); } catch { throw problem('FORBIDDEN', 'The calling page could not be verified.'); }
  const allowed = (url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname))
    || url.origin === 'https://cv-tailor-ddd12.web.app'
    || (url.origin === 'https://scout-38aa2.web.app' && url.pathname.startsWith('/cv-anonymiser/'))
    || (url.origin === 'https://yissok.github.io' && url.pathname.startsWith('/cv-anonymiser-dist/'));
  if (!allowed) throw problem('FORBIDDEN', 'This application is not allowed to use ChatGPT Browser Bridge.');
  return `${url.origin}|${sender.tab.id}`;
}

export function publicJob(job) {
  return clone({id: job.id, requestId: job.requestId, state: job.state, status: job.state, message: job.message,
    createdAt: job.createdAt, updatedAt: job.updatedAt, retryAt: job.retryAt || null, tabId: job.tabId || null,
    chatUrl: job.chatUrl || (job.tabId ? 'https://chatgpt.com/' : null), replyCharacters: job.replyCharacters || 0,
    ...(job.result ? {result: job.result} : {}), ...(job.error ? {error: job.error} : {})});
}

/** Durable, single-job scheduler. Each pump performs at most one bounded page action. */
export function createBridgeService({load, save, tabs, page, now = Date.now, uuid = () => crypto.randomUUID(), digest = async text => {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, '0')).join('');
}}) {
  let state;
  let storageFailed = false;
  let sequence = Promise.resolve();
  const ready = (async () => {
    const stored = await load();
    state = stored?.version === 1 && Array.isArray(stored.jobs)
      ? stored : {version: 1, jobs: [], lastSentAt: 0, cooldownUntil: 0, cooldownLevel: 0};
    state.jobs = state.jobs.filter(job => job && STATES.has(job.state) && typeof job.id === 'string');
    for (const job of state.jobs) {
      if (job.state === 'submitting') finish(job, 'needs_attention', 'SEND_UNCERTAIN', 'The extension restarted while sending. Check the dedicated ChatGPT tab before starting again.');
    }
    await persist();
  })();
  const exclusive = operation => {
    const result = sequence.then(() => ready).then(operation);
    sequence = result.catch(() => {});
    return result;
  };
  async function persist() {
    // Fit Chrome local storage while retaining all pending prompts and the newest result.
    const size = () => new TextEncoder().encode(JSON.stringify(state)).byteLength;
    while (size() > 8 * 1024 * 1024) {
      const oldest = state.jobs.findIndex((job, index) => TERMINAL_STATES.has(job.state) && index !== state.jobs.length - 1);
      if (oldest < 0) { storageFailed = true; throw problem('STORAGE_FULL', 'The browser bridge storage is full. Reload the extension after finishing existing jobs.'); }
      state.jobs.splice(oldest, 1);
    }
    try { await save(clone(state)); }
    catch (error) { storageFailed = true; throw error; }
  }
  function update(job, status, message) {
    job.state = status; job.message = message; job.updatedAt = now();
  }
  function finish(job, status, code, message) {
    update(job, status, message);
    if (code) job.error = {code, message};
    delete job.prompt; delete job.retryAt; delete job.retrying;
  }
  async function cooldown(job, error, increase = true) {
    if (increase) state.cooldownLevel = Math.min((state.cooldownLevel || 0) + 1, COOLDOWNS.length);
    const duration = increase ? COOLDOWNS[Math.max(0, state.cooldownLevel - 1)] : 60_000;
    state.cooldownUntil = Math.max(state.cooldownUntil || 0, now() + duration);
    job.retryAt = state.cooldownUntil; job.retrying = true;
    update(job, 'cooldown', `${error.message || 'ChatGPT reached a message limit.'} Waiting before checking recovery.`);
    await persist();
  }
  function owned(id, owner) {
    const job = state.jobs.find(item => item.id === id && item.owner === owner);
    if (!job) throw problem('JOB_NOT_FOUND', 'This job is unavailable to this browser tab.');
    return job;
  }
  async function ensurePage(job) {
    const tab = await tabs.get(job.tabId);
    // A newly created tab can expose its blank document while the requested
    // first navigation is pending. This exception never applies after Send.
    if (job.state === 'checking' && tab?.url === 'about:blank' && /^https:\/\/chatgpt\.com(?:\/|$)/u.test(tab.pendingUrl || '')) {
      throw problem('PAGE_UNREACHABLE', 'The dedicated ChatGPT tab is still loading.');
    }
    if (!/^https:\/\/chatgpt\.com(?:\/|$)/u.test(tab?.url || tab?.pendingUrl || '')) throw problem('PAGE_CHANGED', 'The dedicated ChatGPT tab moved to another website.');
    if (job.state === 'checking' && !job.continueFrom && new URL(tab.url || tab.pendingUrl).pathname !== '/') throw problem('PAGE_CHANGED', 'The dedicated tab switched to another conversation before sending. No prompt has been sent.');
    job.chatUrl = tab.url || 'https://chatgpt.com/';
    const probe = await page(job.tabId, 'probe', {});
    if (!probe?.ok) throw problem(probe?.error?.code || 'PAGE_UNREACHABLE', probe?.error?.message || 'The dedicated ChatGPT tab is not ready.');
    if (job.state === 'checking' && job.continueFrom) {
      if (probe.documentToken !== job.documentToken) throw problem('PAGE_CHANGED', 'The selection conversation reloaded. Start a new run so its context can be verified. Nothing was sent.');
      const previous = await page(job.tabId, 'requestStatus', {requestId: job.continueFrom});
      if (!previous?.ok || !previous.canContinue) throw problem('PAGE_CHANGED', 'The previous reply is no longer the latest completed turn in this conversation. Start a new run. Nothing was sent.');
    }
    return probe;
  }
  const attentionCodes = new Set(['PAGE_CHANGED', 'REQUEST_NOT_FOUND', 'PAGE_UNREACHABLE', 'SEND_UNCERTAIN', 'ADAPTER_OUTDATED']);
  async function pumpStep() {
    if (storageFailed) throw problem('STORAGE_ERROR', 'Bridge storage failed. Reload the extension before continuing.');
    // Queue order is stable; a cooldown blocks later work on the same account.
    const job = state.jobs.find(item => !TERMINAL_STATES.has(item.state));
    if (!job) return {active: false};
    try {
      if (job.state === 'queued') {
        if (!job.confirmed) {
          if (now() - job.createdAt > 60_000) {
            finish(job, 'cancelled', 'CLIENT_DISCONNECTED', 'The app did not acknowledge this job. Nothing was sent to ChatGPT.');
            await persist(); return {active: true, nextAt: now()};
          }
          return {active: true, nextAt: now() + 1500};
        }
        update(job, 'checking', job.continueFrom ? 'Continuing in the previous ChatGPT conversation.' : 'Opening a dedicated ChatGPT tab.'); await persist();
        return {active: true, nextAt: now()};
      }
      if (job.state === 'checking') {
        if (!job.tabId) {
          const tab = await tabs.create({url: 'https://chatgpt.com/', active: false});
          job.tabId = tab.id; job.chatUrl = tab.url || 'https://chatgpt.com/'; job.pageOpenedAt = now();
          await persist(); return {active: true, nextAt: now() + 1000};
        }
        let probe;
        try { probe = await ensurePage(job); }
        catch (error) {
          if (error.code === 'PAGE_UNREACHABLE' && now() - job.pageOpenedAt < 30_000) return {active: true, nextAt: now() + 1500};
          throw error;
        }
        if (!probe.ready) {
          if (now() - job.pageOpenedAt < 30_000 && ['COMPOSER_NOT_FOUND', 'COMPOSER_DISABLED'].includes(probe.readinessCode)) return {active: true, nextAt: now() + 1500};
          throw problem(probe.readinessCode || 'NOT_READY', probe.readinessMessage || 'Open the dedicated ChatGPT tab and complete sign-in or browser verification.');
        }
        const sendAt = Math.max((state.lastSentAt || 0) + 10_000, state.cooldownUntil || 0);
        if (sendAt > now()) {
          job.retryAt = sendAt; job.message = 'Waiting for the shared ChatGPT message spacing.'; await persist();
          return {active: true, nextAt: sendAt};
        }
        job.documentToken = probe.documentToken;
        update(job, 'submitting', job.delivery === 'attachment' ? 'Uploading the request as a text file, then sending it to ChatGPT.' : 'Sending the prompt to ChatGPT.');
        state.lastSentAt = now();
        await persist(); // Ambiguous acknowledgement must never cause another Send.
        const response = await page(job.tabId, 'submit', {requestId: job.id, text: job.prompt, prompt: job.prompt, format: job.format, delivery: job.delivery || 'text', trackRequest: true, expectedDocumentToken: job.documentToken, ...(job.continueFrom ? {continueFrom: job.continueFrom} : {})});
        if (job.cancelRequested) {
          finish(job, 'cancelled', 'CANCELLED', 'ChatGPT job cancelled.'); await persist();
          return {active: true, nextAt: now()};
        }
        if (response?.ok !== true) {
          if (response?.error?.code === 'RATE_LIMIT') { delete job.prompt; await cooldown(job, response.error); return {active: true, nextAt: job.retryAt}; }
          throw problem(response?.error?.code || 'SEND_UNCERTAIN', response?.error?.message || 'Sending could not be confirmed. Check the dedicated ChatGPT tab.');
        }
        delete job.prompt; delete job.retryAt;
        update(job, 'waiting', 'Waiting for ChatGPT’s complete reply.'); await persist();
        return {active: true, nextAt: now() + 1200};
      }
      if (job.state === 'cooldown') {
        if (now() < job.retryAt) return {active: true, nextAt: job.retryAt};
        const probe = await ensurePage(job);
        if (probe.documentToken !== job.documentToken) throw problem('PAGE_CHANGED', 'The ChatGPT tab reloaded during the cooldown. Check its conversation before retrying.');
        update(job, 'submitting', 'Checking whether ChatGPT can continue the rejected request.');
        state.lastSentAt = now(); await persist();
        const result = await page(job.tabId, 'retryRateLimited', {requestId: job.id});
        if (!result?.ok) {
          const error = result?.error || {code: 'SEND_UNCERTAIN', message: 'The recovery attempt could not be confirmed.'};
          if (['RATE_LIMIT', 'RETRY_NOT_READY', 'RETRY_UNCONFIRMED'].includes(error.code)) {
            await cooldown(job, error, error.code === 'RATE_LIMIT'); return {active: true, nextAt: job.retryAt};
          }
          throw problem(error.code, error.message);
        }
        delete job.retryAt; update(job, 'waiting', 'Waiting for ChatGPT’s reply after the message limit.'); await persist();
        return {active: true, nextAt: now() + 1200};
      }
      if (job.state === 'waiting') {
        const probe = await ensurePage(job);
        if (probe.documentToken !== job.documentToken) throw problem('PAGE_CHANGED', 'The ChatGPT tab reloaded. Check the conversation; the prompt will not be resent.');
        if (now() - job.createdAt > 24 * 60 * 60_000) throw problem('REPLY_TIMEOUT', 'This job has waited for a day. Check the dedicated ChatGPT conversation.');
        const result = await page(job.tabId, 'waitForReply', {requestId: job.id, timeoutMs: 1000});
        if (result?.ok) {
          if (typeof result.text !== 'string' || !result.text.trim()) throw problem('EMPTY_REPLY', 'ChatGPT returned an empty reply.');
          job.result = {text: result.text, codeBlocks: Array.isArray(result.codeBlocks) ? result.codeBlocks : []};
          state.cooldownUntil = 0; state.cooldownLevel = 0;
          finish(job, 'complete', null, 'ChatGPT reply received.'); await persist();
          return {active: true, nextAt: now()};
        }
        const error = result?.error || {code: 'PAGE_UNREACHABLE', message: 'The ChatGPT page stopped responding.'};
        if (error.code === 'REPLY_TIMEOUT') {
          // Observation only: never repeat a prompt merely because a reply is slow.
          const status = await page(job.tabId, 'requestStatus', {requestId: job.id});
          if (status?.ok === false && status.error?.code === 'REQUEST_NOT_FOUND') throw problem('REQUEST_NOT_FOUND', status.error.message);
          job.replyCharacters = status?.replyCharacters || 0; job.updatedAt = now(); await persist();
          return {active: true, nextAt: now() + 1200};
        }
        if (['RATE_LIMIT', 'RETRY_NOT_READY', 'RETRY_UNCONFIRMED'].includes(error.code)) {
          await cooldown(job, error, error.code === 'RATE_LIMIT'); return {active: true, nextAt: job.retryAt};
        }
        throw problem(error.code, error.message);
      }
    } catch (error) {
      if (job.cancelRequested) {
        finish(job, 'cancelled', 'CANCELLED', 'ChatGPT job cancelled.'); await persist();
        return {active: true, nextAt: now()};
      }
      const unsafe = job.state === 'submitting' || attentionCodes.has(error.code) || ['COMPOSER_NOT_FOUND', 'COMPOSER_DISABLED', 'PAGE_CHALLENGE', 'GENERATION_BUSY', 'NOT_READY'].includes(error.code);
      finish(job, unsafe ? 'needs_attention' : 'error', error.code || (unsafe ? 'SEND_UNCERTAIN' : 'BRIDGE_ERROR'), error.message || 'ChatGPT needs your attention.');
      await persist(); return {active: true, nextAt: now()};
    }
    return {active: true, nextAt: now() + 1500};
  }
  async function cancelJob(job, code = 'CANCELLED', message = 'ChatGPT job cancelled.') {
    if (TERMINAL_STATES.has(job.state)) return;
    finish(job, 'cancelled', code, message); await persist();
    if (job.tabId) {
      const tab = await tabs.get(job.tabId).catch(() => null);
      if (/^https:\/\/chatgpt\.com(?:\/|$)/u.test(tab?.url || '')) {
        const probe = await page(job.tabId, 'probe', {}).catch(() => null);
        if (probe?.documentToken === job.documentToken) {
          const status = await page(job.tabId, 'requestStatus', {requestId: job.id}).catch(() => null);
          await page(job.tabId, 'stop', {requestId: job.id, stopGeneration: status?.ok === true}).catch(() => {});
        }
      }
    }
  }
  async function handle(message, sender) {
    const owner = ownerFor(sender);
    if (storageFailed) throw problem('STORAGE_ERROR', 'Bridge storage failed. Reload the extension before continuing.');
    if (message?.version !== 1) throw problem('PROTOCOL_MISMATCH', 'Update the app and ChatGPT Browser Bridge to compatible versions.');
    const data = message.payload || {};
    if (message.action === 'ping') return {protocol: 1, version: '0.1.2', provider: 'chatgpt-browser', maxPromptLength: MAX_PROMPT_LENGTH, capabilities: ['conversation-continuation']};
    if (message.action === 'submit') {
      if (typeof data.prompt !== 'string' || !data.prompt.trim() || data.prompt.length > MAX_PROMPT_LENGTH) throw problem('INVALID_PROMPT', `Provide a prompt containing 1–${MAX_PROMPT_LENGTH.toLocaleString()} characters.`);
      if (!['text', 'json', 'latex'].includes(data.format)) throw problem('INVALID_FORMAT', 'Choose text, json or latex reply extraction.');
      // Older clients do not declare delivery. Keep them usable with large
      // requests without relying on the site's large-paste conversion.
      const delivery = data.delivery || (data.prompt.length > 16000 ? 'attachment' : 'text');
      if (!['text', 'attachment'].includes(delivery)) throw problem('INVALID_DELIVERY', 'Choose text or attachment delivery.');
      if (typeof data.requestId !== 'string' || !/^[\w-]{1,100}$/u.test(data.requestId)) throw problem('INVALID_REQUEST', 'Provide a unique request ID of up to 100 letters, digits or hyphens.');
      if (data.continueFrom !== undefined && (typeof data.continueFrom !== 'string' || !/^[\w-]{1,100}$/u.test(data.continueFrom))) throw problem('INVALID_CONTINUATION', 'Provide a completed bridge job ID to continue its conversation.');
      const fingerprint = await digest(`${data.format}\0${data.prompt}${delivery === 'attachment' ? '\0attachment' : ''}${data.continueFrom ? `\0continue:${data.continueFrom}` : ''}`);
      const existing = state.jobs.find(job => job.owner === owner && job.requestId === data.requestId);
      if (existing) {
        if (existing.fingerprint !== fingerprint) throw problem('REQUEST_CONFLICT', 'This request ID was already used for another prompt.');
        return publicJob(existing);
      }
      let previous;
      if (data.continueFrom) {
        previous = owned(data.continueFrom, owner);
        if (previous.state !== 'complete' || !previous.tabId || !previous.documentToken) throw problem('INVALID_CONTINUATION', 'Only a completed, verified bridge conversation can be continued.');
        if (state.jobs.some(job => job !== previous && job.tabId === previous.tabId && state.jobs.indexOf(job) > state.jobs.indexOf(previous))) throw problem('CONVERSATION_BUSY', 'This conversation already has a follow-up request. Continue from its latest completed job instead.');
      }
      // Retain bounded history; never silently discard pending work.
      const pending = state.jobs.filter(job => !TERMINAL_STATES.has(job.state));
      if (pending.length >= 10) throw problem('QUEUE_FULL', 'Wait for current ChatGPT jobs to finish before adding more.');
      const history = state.jobs.filter(job => TERMINAL_STATES.has(job.state)).slice(-19);
      state.jobs = [...state.jobs.filter(job => !TERMINAL_STATES.has(job.state)), ...history].sort((a, b) => a.createdAt - b.createdAt);
      const job = {id: uuid(), owner, requestId: data.requestId, fingerprint, format: data.format, delivery, prompt: data.prompt,
        ...(previous ? {continueFrom: previous.id, tabId: previous.tabId, documentToken: previous.documentToken, chatUrl: previous.chatUrl, pageOpenedAt: now()} : {}),
        state: 'queued', message: 'Waiting for the ChatGPT browser bridge.', createdAt: now(), updatedAt: now()};
      state.jobs.push(job);
      try { await persist(); }
      catch (error) { state.jobs = state.jobs.filter(item => item.id !== job.id); throw error; }
      return publicJob(job);
    }
    if (!['get', 'cancel'].includes(message.action)) throw problem('UNKNOWN_ACTION', 'This bridge action is unsupported.');
    const job = data.id ? owned(data.id, owner) : state.jobs.find(item => item.owner === owner && item.requestId === data.requestId);
    if (!job) throw problem('JOB_NOT_FOUND', 'This job is unavailable to this browser tab.');
    if (message.action === 'get' && job.state === 'queued' && !job.confirmed) {
      // The caller now knows its durable ID. A lost submit response cannot start work.
      job.confirmed = true; await persist();
    }
    if (message.action === 'cancel') await cancelJob(job);
    return publicJob(job);
  }
  return {
    ready,
    dispatch: async (message, sender) => {
      await ready;
      // Interrupt an upload in the content script before waiting on the queue
      // that is currently awaiting that same upload.
      if (message?.action === 'cancel' && message.version === 1 && !storageFailed) {
        try {
          const owner = ownerFor(sender);
          const data = message.payload || {};
          const job = data.id ? owned(data.id, owner) : state.jobs.find(item => item.owner === owner && item.requestId === data.requestId);
          if (job?.state === 'submitting' && job.tabId) {
            job.cancelRequested = true;
            await page(job.tabId, 'stop', {requestId: job.id, stopGeneration: true}).catch(() => {});
          }
        } catch (error) { return {ok: false, error: {code: error.code || 'BRIDGE_ERROR', message: error.message}}; }
      }
      // Status reads must not queue behind a slow browser action. Keep initial
      // acknowledgement and terminal results serialized with durable writes.
      if (message?.action === 'get' && message.version === 1 && !storageFailed) {
        try {
          const owner = ownerFor(sender);
          const job = owned(message.payload?.id, owner);
          if (job.confirmed && !TERMINAL_STATES.has(job.state)) return {ok: true, value: publicJob(job)};
        } catch (error) {
          return {ok: false, error: {code: error.code || 'BRIDGE_ERROR', message: error.message}};
        }
      }
      return exclusive(async () => {
      try { return {ok: true, value: await handle(message, sender)}; }
      catch (error) { return {ok: false, error: {code: error.code || 'STORAGE_ERROR', message: error.message || 'The browser bridge could not save this request.'}}; }
      });
    },
    pump: () => exclusive(pumpStep),
    snapshot: () => exclusive(() => clone(state)),
    cancelOwnerTab: tabId => exclusive(async () => {
      for (const job of state.jobs.filter(item => item.owner.endsWith(`|${tabId}`) && !TERMINAL_STATES.has(item.state))) {
        await cancelJob(job, 'CLIENT_DISCONNECTED', 'The requesting app was closed or reloaded. Its unfinished job was cancelled.');
      }
    }),
  };
}
