/* Public page transport. The service independently checks the trusted sender URL. */
(() => {
  'use strict';
  const channel = 'chatgpt-browser-bridge';
  if (window.top !== window || window.__chatgptBrowserBridgePageInstalled) return;
  const url = new URL(location.href);
  const allowed = (url.protocol === 'http:' && ['localhost', '127.0.0.1'].includes(url.hostname))
    || url.origin === 'https://cv-tailor-ddd12.web.app'
    || (url.origin === 'https://scout-38aa2.web.app' && url.pathname.startsWith('/cv-anonymiser/'))
    || (url.origin === 'https://yissok.github.io' && url.pathname.startsWith('/cv-anonymiser-dist/'));
  if (!allowed) return;
  window.__chatgptBrowserBridgePageInstalled = true;
  window.addEventListener('message', async event => {
    const message = event.data;
    if (event.source !== window || event.origin !== location.origin || message?.channel !== channel || message.direction !== 'request' || message.version !== 1) return;
    if (typeof message.id !== 'string' || !/^[\w-]{1,100}$/.test(message.id) || !['ping', 'submit', 'get', 'cancel'].includes(message.action)) return;
    let response;
    try {
      response = await chrome.runtime.sendMessage({target: 'browser-bridge-service', version: 1, action: message.action, payload: message.payload});
    } catch {
      response = {ok: false, error: {code: 'BRIDGE_UNAVAILABLE', message: 'Reload this app after installing or updating ChatGPT Browser Bridge.'}};
    }
    window.postMessage({channel, direction: 'response', version: 1, id: message.id, ...response}, location.origin);
  });
})();
