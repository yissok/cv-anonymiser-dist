/* Text adapter derived from ChatGPT Readback v0.8.7. Uses visible page controls only.
 * No account credentials, private endpoints, speech controls or audio capture. */
(function installChatGPTPageAdapter(global) {
  "use strict";

  const TARGET = "chatgpt-bridge-content";
  const ADAPTER_VERSION = "1.0.0";
  const BUILD_ID = "chatgpt-browser-bridge-completion-7";
  const MAX_TEXT_LENGTH = 2200000;
  const KNOWN_COMPOSER = '#prompt-textarea, [data-testid="prompt-textarea"], [data-testid="composer-text-input"]';
  const MODERN_COMPOSER = '.ProseMirror[data-composer-markdown][role="textbox"][aria-multiline="true"][contenteditable]';
  const EDITORS = `${KNOWN_COMPOSER}, textarea, [contenteditable], [role="textbox"]`;
  const COMPOSER_SCOPE = 'form, [data-testid="composer"], #composer-background, [data-type="unified-composer"], [data-testid="composer-text-input"]';
  const SEND_CONTROL = '[data-testid="send-button"], [data-testid="composer-submit-button"], [data-testid="composer-send-button"], button[aria-label="Send prompt"], button[aria-label="Send message"]';
  const GENERATION_STOP = '[data-testid="stop-button"], button[aria-label="Stop generating"], button[aria-label="Stop streaming"]';
  const AUTHOR_MESSAGES = '[data-message-author-role="user"], [data-message-author-role="assistant"]';
  const TURN_MESSAGES = '[data-turn="user"], [data-turn="assistant"]';
  const TURN_ROLE_MESSAGES = '[data-turn-role="user"], [data-turn-role="assistant"]';
  const SEARCH_USER_MESSAGES = '[data-content-search-unit-key$=":user"], [data-chatgpt-search-unit-key$=":user"]';
  const SEARCH_ASSISTANT_MESSAGES = '[data-content-search-unit-key$=":assistant"], [data-chatgpt-search-unit-key$=":assistant"]';
  const SEARCH_MESSAGES = `${SEARCH_USER_MESSAGES}, ${SEARCH_ASSISTANT_MESSAGES}`;
  const ROLE_MESSAGES = `${AUTHOR_MESSAGES}, ${TURN_MESSAGES}, ${TURN_ROLE_MESSAGES}, ${SEARCH_MESSAGES}`;
  const MESSAGE_CONTAINERS = `article, [role="article"], [data-testid^="conversation-turn-"], ${TURN_MESSAGES}, ${TURN_ROLE_MESSAGES}, ${SEARCH_MESSAGES}`;
  const normalize = (value) => String(value || "").normalize("NFC").replace(/\s+/gu, " ").trim();
  const exact = (value, pattern) => pattern.test(normalize(value));

  class AdapterError extends Error {
    constructor(code, message, retryable = false) {
      super(message);
      this.code = code;
      this.retryable = retryable;
    }
  }

  function createAdapter(document, options = {}) {
    const now = options.now || (() => Date.now());
    const sleep = options.sleep || ((ms) => new Promise((resolve) => global.setTimeout(resolve, ms)));
    const documentToken = options.documentToken || `page-${now()}-${Math.random().toString(36).slice(2)}`;
    const requests = new Map();

    function all(selector, root = document) {
      return Array.from(root.querySelectorAll(selector));
    }

    function visible(element) {
      if (!element || element.hidden || element.getAttribute("aria-hidden") === "true") return false;
      if (element.closest('[hidden], [aria-hidden="true"]')) return false;
      for (let ancestor = element; ancestor; ancestor = ancestor.parentElement) {
        const style = document.defaultView?.getComputedStyle?.(ancestor);
        if (style && (style.display === "none" || /^(hidden|collapse)$/u.test(style.visibility) || style.contentVisibility === "hidden" || style.opacity === "0")) return false;
      }
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    }

    function inViewport(element) {
      const rect = element.getBoundingClientRect();
      const viewport = document.defaultView;
      // A hidden backing textarea can have a tiny, far-offscreen box. Do not
      // mistake it for the visible editor used by current ChatGPT layouts.
      if (viewport?.innerWidth && Number.isFinite(rect.left) && Number.isFinite(rect.right) && (rect.right <= 0 || rect.left >= viewport.innerWidth)) return false;
      if (viewport?.innerHeight && Number.isFinite(rect.top) && Number.isFinite(rect.bottom) && (rect.bottom <= 0 || rect.top >= viewport.innerHeight)) return false;
      return true;
    }

    function visibleComposer(element) {
      return visible(element) && inViewport(element);
    }

    function label(element) {
      return element.getAttribute("aria-label") || element.getAttribute("title") || element.innerText || element.textContent || "";
    }

    function buttons(root = document) {
      return all('button, [role="button"], [role="menuitem"]', root).filter(visible);
    }

    function enabled(element) {
      return !element.disabled && !element.matches(":disabled") && !element.closest('[inert], [aria-disabled="true"]');
    }

    function rateLimitAlert() {
      return all('[role="alert"]').filter(visible).findLast(element=>
        !element.closest('.markdown, [data-markdown-copy], .whitespace-pre-wrap') &&
        /(?:reached|hit)[\s\S]{0,80}(?:limit of messages|message limit)|too many (?:requests|messages)|(?:message|rate) limit[\s\S]{0,80}(?:reached|try again|later)/iu.test(normalize(element.textContent)));
    }

    function chatMemoryFull() {
      return all('aside[role="status"], [role="alert"], [role="status"]').filter(visible).some(element=>
        !element.closest(MESSAGE_CONTAINERS) && !element.closest(ROLE_MESSAGES) &&
        all('h1, h2, h3, h4, h5, h6',element).some(heading=>exact(heading.textContent,/^chat memory full$/iu)) &&
        buttons(element).some(button=>exact(label(button),/^continue in a new chat$/iu)));
    }
    function assertChatMemoryAvailable() {
      if(chatMemoryFull())throw new AdapterError('CHAT_MEMORY_FULL','ChatGPT reports Chat memory full. Opening a fresh chat for the unfinished chunk.',true);
    }

    function watchRateLimit(request) {
      request.limitWatch?.observer?.disconnect();
      const baseline=rateLimitAlert();
      const watch=request.limitWatch={baseline,message:limitMessage(baseline),button:baseline && buttons(baseline).find(button=>exact(label(button),/^retry$/iu)),retryPending:false,cleared:!baseline,observer:null};
      const Observer=document.defaultView?.MutationObserver;
      if(baseline && Observer){watch.observer=new Observer(records=>observeLimitControl(watch,records));watch.observer.observe(baseline,{subtree:true,childList:true,characterData:true,attributes:true,attributeOldValue:true,attributeFilter:['disabled','aria-disabled','aria-busy']});}
    }

    function limitMessage(alert) {
      if(!alert)return '';
      const copy=alert.cloneNode(true);for(const control of all('button, [role="button"]',copy))control.remove();
      return normalize(copy.textContent);
    }

    function observeLimitControl(watch,records) {
      if(!watch.button)return;
      if(!enabled(watch.button) || !exact(label(watch.button),/^retry$/iu))watch.retryPending=true;
      if(records.some(record=>record.target===watch.button && record.type==='attributes' && (record.attributeName==='disabled' && record.oldValue!==null || record.attributeName==='aria-disabled' && record.oldValue==='true')))watch.retryPending=true;
    }

    function assertNotRateLimited(request,reply) {
      const alert=rateLimitAlert();
      const watch=request.limitWatch;
      if(!alert){if(watch)watch.cleared=true;return;}
      if(reply?.text.trim() && normalize(reply.text)===normalize(request.text) && !replyCompletion(reply).completionBlocked)return;
      if(watch)observeLimitControl(watch,watch.observer?.takeRecords() || []);
      const retryFinished=watch?.retryPending && buttons(alert).some(button=>enabled(button) && exact(label(button),/^retry$/iu));
      if(watch?.baseline && !watch.cleared && alert===watch.baseline && limitMessage(alert)===watch.message && !retryFinished)return;
      // A retry can leave the old alert on screen while the request loads.
      // Its disabled/loading control is not proof of another rejection.
      if(request.retryInProgress && (generationButton() || watch?.retryPending && !retryFinished && alert===watch.baseline || buttons(alert).some(button=>exact(label(button),/^retry$/iu) && !enabled(button))))return;
      watch?.observer?.disconnect();request.retryInProgress=false;
      request.phase='rate-limited';request.rateLimited=true;
      throw new AdapterError('RATE_LIMIT', normalize(alert.textContent).replace(/\s*Retry$/iu,'').slice(0,1000), true);
    }

    function contentEditable(element) {
      // The empty attribute enables editing too. Invalid attribute values
      // inherit from the nearest ancestor, as does an omitted attribute.
      for (let ancestor = element; ancestor; ancestor = ancestor.parentElement) {
        const value = ancestor.getAttribute('contenteditable');
        if (value === null) continue;
        if (/^(?:|true|plaintext-only)$/i.test(value)) return true;
        if (/^false$/i.test(value)) return false;
      }
      return element.isContentEditable === true;
    }

    function writable(element) {
      if (!enabled(element) || element.readOnly || element.getAttribute("aria-readonly") === "true") return false;
      return /^(textarea|input)$/i.test(element.tagName) || contentEditable(element);
    }

    function hasComposerControl(scope) {
      return all(`${SEND_CONTROL}, ${GENERATION_STOP}`, scope).some((control) => {
        if (control.closest(`${MESSAGE_CONTAINERS}, ${AUTHOR_MESSAGES}, [role="menu"]`)) return false;
        if (control.matches(SEND_CONTROL)) return true;
        return /^(?:stop(?: generating| streaming)?(?: response)?)?$/i.test(normalize(label(control)));
      });
    }

    function composerSelection() {
      const raw = all(EDITORS);
      const excluded = { message: 0, dialog: 0, unscoped: 0, notEditor: 0, hidden: 0, offscreen: 0 };
      const details = raw.map((element) => {
        const legacyKnown = element.matches(KNOWN_COMPOSER);
        const modern = element.matches(MODERN_COMPOSER);
        const known = legacyKnown || modern;
        const scope = composerScope(element);
        let exclusion = null;
        // A known input can live inside ChatGPT's conversation dialog. Message
        // editing controls remain excluded even when they reuse its input id.
        if (element.closest(`${MESSAGE_CONTAINERS}, ${AUTHOR_MESSAGES}`)) exclusion = 'message';
        else if (element.matches(COMPOSER_SCOPE) && !element.matches('#prompt-textarea, [data-testid="prompt-textarea"]') && element.querySelector('textarea, [role="textbox"], [contenteditable="true"], [contenteditable=""], [contenteditable="plaintext-only"]')) exclusion = 'notEditor';
        else if (!legacyKnown && element.closest('[role="dialog"]')) exclusion = 'dialog';
        else if (!known && !element.matches('textarea, [contenteditable]') && !contentEditable(element)) exclusion = 'notEditor';
        else if (element.closest('[role="search"], [data-testid="canvas"], [data-testid="canvas-editor"], .cm-editor')) exclusion = 'unscoped';
        // The current home-page composer has no Send control until text is
        // entered. Its ProseMirror marker identifies the editor independently,
        // but it must still belong to its own form/composer container.
        else if (modern && !scope) exclusion = 'unscoped';
        // Unknown editors need a recognized Send/Stop control in their own
        // composer container. Never bind to an arbitrary page or canvas editor.
        else if (!known && (!scope || !hasComposerControl(scope))) exclusion = 'unscoped';
        const rendered = visible(element);
        const insideViewport = inViewport(element);
        if (exclusion) excluded[exclusion]++;
        else if (!rendered) excluded.hidden++;
        else if (!insideViewport) excluded.offscreen++;
        return { element, known, exclusion, rendered, insideViewport };
      });
      const candidates = details.filter((item) => !item.exclusion).map((item) => item.element);
      const shown = candidates.filter(visibleComposer);
      const editable = shown.filter(writable);
      const rank = (element) => element.matches(`${KNOWN_COMPOSER}, ${MODERN_COMPOSER}`) ? 0 : 1;
      editable.sort((a, b) => rank(a) - rank(b));
      // Report only bounded structural metadata. Input values, placeholder
      // text, labels, conversation text, and URLs never enter diagnostics.
      const editorCandidates = [...details].sort((a, b) => (a.known ? 0 : a.exclusion ? 2 : 1) - (b.known ? 0 : b.exclusion ? 2 : 1)).slice(0, 12).map((item) => ({
        tag: item.element.tagName.toLowerCase(),
        id: (item.element.id || '').slice(0, 80),
        testId: (item.element.getAttribute('data-testid') || '').slice(0, 80),
        role: (item.element.getAttribute('role') || '').slice(0, 40),
        contentEditable: item.element.getAttribute('contenteditable')?.slice(0, 40) ?? null,
        rendered: item.rendered, inViewport: item.insideViewport, editable: writable(item.element),
        exclusion: item.exclusion || (!item.rendered ? 'hidden' : !item.insideViewport ? 'offscreen' : null),
      }));
      return { candidates, shown, editable, composer: editable[0] || shown[0] || null, rawEditorCandidates: raw.length, excluded, editorCandidates };
    }

    function composerScope(composer) {
      // composer-text-input is sometimes a wrapper and sometimes the editor
      // itself. A scope must contain both the editor and its Send control.
      let start = composer;
      if (start?.matches('textarea, [contenteditable], [role="textbox"]')) start = start.parentElement;
      const scopes = [];
      for (let ancestor = start; ancestor; ancestor = ancestor.parentElement) {
        if (ancestor.matches(COMPOSER_SCOPE)) scopes.push(ancestor);
      }
      return scopes.find(hasComposerControl) || scopes[0] || null;
    }

    function pageKind() {
      const path = currentPath() || '';
      if (/\/(?:c)\/[^/]+/u.test(path)) return 'conversation';
      if (/^\/share(?:\/|$)/u.test(path)) return 'shared';
      if (/\/(?:project|projects)(?:\/|$)/u.test(path) || /^\/g\/[^/]+\/project(?:\/|$)/u.test(path)) return 'project';
      return path === '/' ? 'home' : 'other';
    }

    function generationButton(composer = composerSelection().composer) {
      const selectedComposer = composer || composerSelection().candidates[0];
      const scope = composerScope(selectedComposer);
      return all(GENERATION_STOP).find((element) => {
        if (!visible(element) || !enabled(element)) return false;
        if (element.closest(`${MESSAGE_CONTAINERS}, ${AUTHOR_MESSAGES}, [role="menu"]`)) return false;
        const dialog = element.closest('[role="dialog"]');
        if (dialog && (!scope?.contains(element) || selectedComposer?.closest('[role="dialog"]') !== dialog)) return false;
        const controlLabel = normalize(label(element));
        if (/audio|read aloud|reading|voice|recording|dictation|transcription/i.test(controlLabel)) return false;
        // Explicit generation labels also support layouts where the control
        // lives beside the form. The generic test id is only meaningful within
        // our composer; ChatGPT reuses stop controls for audio and other tools.
        if (/^stop (?:generating|streaming)(?: response)?$/i.test(controlLabel)) return true;
        return !!scope && scope.contains(element) && element.getAttribute("data-testid") === "stop-button" && /^(?:stop)?$/i.test(controlLabel);
      });
    }

    function attachmentRemoveButtons(composer) {
      const scope = composerScope(composer);
      // The real attachment's remove button is opacity:0 until hover/focus.
      // Its containing file chip must be visible; the button itself need not be.
      return scope ? all('button, [role="button"]', scope).filter(button =>
        !button.closest('[hidden], [aria-hidden="true"]') && visible(button.parentElement) &&
        /^(?:remove (?:file|attachment)\b|remove .+\.[\p{L}\p{N}]{1,12}$)/iu.test(normalize(label(button)))) : [];
    }

    function hasAttachments(composer) {
      return attachmentRemoveButtons(composer).length > 0;
    }

    function readiness() {
      const selection = composerSelection();
      const composer = selection.composer;
      const generation = generationButton(composer);
      const hasDraft = !!composer && !!normalize(composerValue(composer));
      const attachmentsPresent = !!composer && hasAttachments(composer);
      const memoryFull=chatMemoryFull();
      const challengePage = !selection.shown.length && (
        /^(?:just a moment|checking your browser)(?:\b|[.…])/i.test((document.title || '').trim()) ||
        all('#challenge-running, #challenge-stage, #challenge-form').some(visible)
      );
      let code = "READY";
      let message = "ChatGPT is ready.";
      if (generation) {
        code = "GENERATION_BUSY";
        message = "ChatGPT is generating a reply. Wait for it to finish before starting.";
      } else if (challengePage) {
        code = 'PAGE_CHALLENGE';
        message = 'ChatGPT is showing a browser verification page. Finish that check in the ChatGPT tab, then check again.';
      } else if(memoryFull && !hasDraft && !attachmentsPresent) {
        code='CHAT_MEMORY_FULL';
        message='ChatGPT reports Chat memory full. A fresh chat is needed before sending another chunk.';
      } else if (!selection.shown.length) {
        code = "COMPOSER_NOT_FOUND";
        message = "The visible ChatGPT message box could not be found. Open a normal conversation and refresh the ChatGPT tab.";
      } else if (!selection.editable.length) {
        code = "COMPOSER_DISABLED";
        message = "ChatGPT's message box is disabled or read-only. Dismiss any blocking screen and wait for the page to become ready.";
      } else if (hasDraft) {
        code = "COMPOSER_NOT_EMPTY";
        message = "The ChatGPT message box contains an unsent draft. Send or clear it before starting.";
      } else if (attachmentsPresent) {
        code = "ATTACHMENTS_PRESENT";
        message = "Remove the existing attachment from ChatGPT before starting.";
      }
      return {
        ready: code === "READY", readinessCode: code, readinessMessage: message,
        composerFound: selection.shown.length > 0, generating: !!generation,memoryFull,
        diagnostics: {
          rawEditorCandidates: selection.rawEditorCandidates,
          excludedComposers: selection.excluded,
          editorCandidates: selection.editorCandidates,
          documentState: document.readyState,
          visibilityState: document.visibilityState,
          pageKind: pageKind(),
          challengePage,
          composerCandidates: selection.candidates.length,
          visibleComposers: selection.shown.length,
          writableComposers: selection.editable.length,
          composerKind: composer ? `${composer.tagName.toLowerCase()}${composer.hasAttribute("contenteditable") ? "[contenteditable]" : ""}` : null,
          composerSource: composer ? (composer.matches(MODERN_COMPOSER) ? 'prosemirror-composer' : composer.matches(KNOWN_COMPOSER) ? 'stable-id' : 'scoped') : null,
          draftPresent: hasDraft, attachmentsPresent,
          generationControl: generation ? {
            testId: (generation.getAttribute("data-testid") || "").slice(0, 80),
            ariaLabel: normalize(generation.getAttribute("aria-label")).slice(0, 120),
          } : null,
        },
      };
    }

    function articleFor(node) {
      const role = messageRole(node);
      let container = node;
      for (let ancestor = node; ancestor; ancestor = ancestor.parentElement) {
        if (!ancestor.matches(MESSAGE_CONTAINERS)) continue;
        // A toolbar can be outside an inner content marker. Climb only while
        // this remains the same semantic message, never into a wrapper holding
        // another message's controls.
        const ownsOnlyThisMessage = all(ROLE_MESSAGES, ancestor).every((marker) =>
          messageRole(marker) === role && (marker.contains(node) || node.contains(marker)));
        if (!ownsOnlyThisMessage) break;
        container = ancestor;
      }
      return container;
    }

    function messageRole(node) {
      return [node.getAttribute('data-message-author-role'), node.getAttribute('data-turn-role'), node.getAttribute('data-turn'),
        node.getAttribute('data-content-search-unit-key')?.split(':').at(-1), node.getAttribute('data-chatgpt-search-unit-key')?.split(':').at(-1),
      ].find((role) => role === 'user' || role === 'assistant') || null;
    }

    function cleanMessageText(content) {
      // Article-level role markers also enclose accessible headings and turn
      // actions. Strip only explicit UI from a detached copy; never loosen the
      // full submitted-prompt comparison to a substring match.
      const copy = content.cloneNode(true);
      for (const control of all('button, [role="button"], [role="menu"], [role="menuitem"], [role="toolbar"], svg, .sr-only, .screen-reader-only, [hidden], [aria-hidden="true"], h1[data-conversation-role], h2[data-conversation-role], h3[data-conversation-role], h4[data-conversation-role], h5[data-conversation-role], h6[data-conversation-role]', copy)) control.remove();
      for (const pre of all('pre', copy)) {
        const code = pre.querySelector('code');
        if (code) pre.replaceChildren(document.createTextNode(code.textContent || ''));
      }
      // Native list markers are painted by the browser, not included in
      // textContent/innerText. Reconstruct them without forgiving missing or
      // changed numbers in the actual reply.
      for (const list of all('ol', copy)) {
        const items = [...list.children].filter(child => child.tagName === 'LI');
        let number = Number(list.getAttribute('start') || (list.hasAttribute('reversed') ? items.length : 1));
        for (const item of items) {
          if (item.hasAttribute('value')) number = Number(item.getAttribute('value'));
          item.prepend(document.createTextNode(`${number}. `));
          number += list.hasAttribute('reversed') ? -1 : 1;
        }
      }
      for (const lineBreak of all('br', copy)) lineBreak.replaceWith(document.createTextNode('\n'));
      for (const list of all('ol, ul',copy)) {list.prepend(document.createTextNode('\n'));list.append(document.createTextNode('\n'));}
      for (const block of all('p, div, section, header, footer, h1, h2, h3, h4, h5, h6, li, pre, blockquote, tr', copy)) block.append(document.createTextNode('\n'));
      return copy.textContent || "";
    }

    function articleMessageText(node, role) {
      const content = node.querySelector(`[data-message-content], [data-testid="${role}-message-content"], [data-testid="${role}-message"]`) || node;
      return cleanMessageText(content);
    }

    function searchUnitFor(node, role = messageRole(node)) {
      return node.closest(role === 'assistant' ? SEARCH_ASSISTANT_MESSAGES : SEARCH_USER_MESSAGES);
    }

    function messageContext(node, role) {
      const unit = searchUnitFor(node, role);
      if (!unit || role !== 'assistant') return { unit, article: articleFor(node), actionRoot: articleFor(node), turnStateNode: null, requiresTurnCompletion: false };
      const turnStateNode = unit.closest('[data-talvt-turn-state]');
      const turn = turnStateNode || unit.closest('[data-content-search-turn-key], [data-turn-key]');
      let toolbar = null;
      if (turn) {
        const assistants = all(SEARCH_ASSISTANT_MESSAGES, turn).filter((candidate) => !candidate.querySelector(SEARCH_ASSISTANT_MESSAGES));
        if (assistants.length === 1 && assistants[0] === unit) {
          const toolbars = all('.turn-action-controls', turn).filter((candidate) =>
            !candidate.closest(SEARCH_USER_MESSAGES) &&
            (!candidate.closest(SEARCH_ASSISTANT_MESSAGES) || unit.contains(candidate)) &&
            (unit.contains(candidate) || !!(unit.compareDocumentPosition(candidate) & 4)));
          if (toolbars.length === 1) toolbar = toolbars[0];
        }
      }
      // The actual workspace groups a user message and its assistant reply in
      // one completed turn. Its sibling toolbar belongs to this reply only
      // when there is exactly one assistant unit and one non-user toolbar.
      return { unit, article: toolbar ? turn : unit, actionRoot: toolbar || unit, turnStateNode, requiresTurnCompletion: true };
    }

    function textFor(node, role) {
      if (node.matches(SEARCH_MESSAGES)) {
        if (role === 'assistant') return cleanMessageText(node);
        const bubble = node.querySelector('[data-user-message-bubble="true"]');
        const content = (bubble || node).querySelector('.whitespace-pre-wrap');
        return content ? content.innerText || content.textContent || '' : cleanMessageText(bubble || node);
      }
      if (role === "assistant") {
        const markdown = all(".markdown", node);
        if (markdown.length) return markdown.map(cleanMessageText).join("\n\n");
        const content = node.querySelector('[data-testid="assistant-message-content"]');
        if (content) return cleanMessageText(content);
      } else {
        const content = node.querySelector(".whitespace-pre-wrap");
        if (content) return content.innerText || content.textContent || "";
      }
      if (node.matches(`${TURN_MESSAGES}, ${TURN_ROLE_MESSAGES}`)) return articleMessageText(node, role);
      return node.innerText || node.textContent || "";
    }

    function codeBlocksFor(reply, strict = false) {
      const root = reply.unit || reply.node;
      // Current ChatGPT renders code in a dedicated source div rather than a
      // pre. Never read the surrounding action bar, language label or analysis.
      const blocks = all('pre, [data-code-block-source="true"]', root).filter(block =>
        !block.closest('[hidden], [aria-hidden="true"]') &&
        !block.querySelector('pre, [data-code-block-source="true"]'));
      return blocks.map(block => {
        const codes = all('code', block).filter(code => !code.parentElement?.closest('code'));
        const code = codes.length === 1 ? codes[0]
          : codes.length === 0 && block.matches('[data-code-block-source="true"]') ? block : null;
        if (!code) {
          if (strict) throw new AdapterError("RESPONSE_FORMAT", "A code block could not be read unambiguously. Inspect the reply in ChatGPT.");
          return { language: '', text: block.textContent || '' };
        }
        const languageClass = [...code.classList, ...block.classList].find(value => /^language-[\w+-]+$/u.test(value));
        const language = (code.getAttribute('data-language') || block.getAttribute('data-language') || languageClass?.slice(9) || '').toLowerCase();
        return { language, text: code.textContent || '' };
      });
    }

    function responseFor(request, reply) {
      const codeBlocks = codeBlocksFor(reply, true);
      let text = reply.text;
      if (request.format !== 'text') {
        const languages = request.format === 'latex' ? ['latex', 'tex'] : ['json'];
        const candidates = codeBlocks.filter(block => languages.includes(block.language));
        let selected;
        if (candidates.length === 1) selected = candidates[0];
        else if (candidates.length > 1) throw new AdapterError('RESPONSE_AMBIGUOUS', 'ChatGPT returned multiple matching code blocks. Inspect the reply before choosing a result.');
        else if (codeBlocks.length === 1 && !codeBlocks[0].language) selected = codeBlocks[0];
        else if (codeBlocks.length) throw new AdapterError('RESPONSE_FORMAT', 'ChatGPT did not return one identifiable code block in the requested format.');
        if (selected) text = selected.text;
        if (request.format === 'json') {
          try { JSON.parse(text); } catch (_) { throw new AdapterError('RESPONSE_FORMAT', 'ChatGPT did not return valid JSON without commentary.'); }
        } else if (!selected || !selected.language) {
          // Plain sources must start with documentclass (allowing comments) and
          // finish at end{document}. Prose around an un-fenced source is unsafe.
          const bare = text.replace(/^\s*(?:%[^\n]*(?:\n|$)\s*)*/u, '');
          if (!/^\\documentclass(?:\[[^\]]*\])?\{[^}]+\}/u.test(bare) ||
              !/\\begin\{document\}/u.test(bare) ||
              !/\\end\{document\}(?:\s|%[^\n]*(?:\n|$))*$/u.test(bare)) {
            throw new AdapterError('RESPONSE_FORMAT', 'ChatGPT did not return a complete LaTeX document without commentary.');
          }
        }
      }
      if (!text.trim()) throw new AdapterError('RESPONSE_FORMAT', 'ChatGPT returned an empty response.');
      if (text.length > MAX_TEXT_LENGTH || codeBlocks.reduce((sum, block) => sum + block.text.length, 0) > MAX_TEXT_LENGTH) {
        throw new AdapterError('RESPONSE_TOO_LARGE', 'The ChatGPT response exceeds 2,200,000 characters.');
      }
      return { text, codeBlocks };
    }

    function messages() {
      const claimedUnits = new Set();
      return all(ROLE_MESSAGES).filter((node) =>
        // Markers can appear on semantic containers of any tag, or on inner
        // content. Prefer the deepest role marker to count each turn once.
        !node.querySelector(ROLE_MESSAGES)
      ).filter((node) => {
        const unit = searchUnitFor(node);
        if (!unit) return true;
        if (claimedUnits.has(unit)) return false;
        claimedUnits.add(unit);
        return true;
      }).map((node, index) => {
        const role = messageRole(node);
        const context = messageContext(node, role);
        const { article, unit } = context;
        const idNode = node.closest("[data-message-id]");
        const messageId = node.getAttribute("data-message-id") || (idNode && idNode.getAttribute("data-message-id"));
        const identityNode = unit?.closest('[data-chatgpt-search-message-ids]');
        const searchMessageIds = [...new Set(normalize(identityNode?.getAttribute('data-chatgpt-search-message-ids')).split(/[\s,]+/u).filter(Boolean))].sort().join(',');
        const sourceMessageId = unit?.querySelector('[data-dil-source-message-id]')?.getAttribute('data-dil-source-message-id');
        const unitKey = unit?.getAttribute('data-content-search-unit-key') || unit?.getAttribute('data-chatgpt-search-unit-key');
        const searchTurn = unit?.closest('[data-content-search-turn-key], [data-turn-key]');
        const turnId = searchTurn?.getAttribute('data-content-search-turn-key') || searchTurn?.getAttribute('data-turn-key') || article.getAttribute("data-testid") || article.id;
        return {
          node, ...context, role, index,
          key: searchMessageIds ? `search-message:${role}:${searchMessageIds}` : sourceMessageId ? `source-message:${role}:${sourceMessageId}` : messageId ? `message:${messageId}` : unitKey ? `unit:${unitKey}` : turnId ? `turn:${turnId}:${role}` : `index:${index}:${role}`,
          turnId: turnId || messageId || null,
          text: textFor(unit || node, role),
        };
      });
    }

    function messageDiagnostics(current = messages()) {
      return {
        assistantCount: current.filter((turn) => turn.role === "assistant").length,
        userCount: current.filter((turn) => turn.role === "user").length,
        recognizedMessageCount: current.length,
        conversationTurnCount: all('article, [data-testid^="conversation-turn-"], [data-talvt-turn-state]').length,
        conversationArticleCount: all('article').length,
        roleArticleCount: all('[role="article"]').length,
        roleMarkerCounts: {
          authorRoleUser: all('[data-message-author-role="user"]').length,
          authorRoleAssistant: all('[data-message-author-role="assistant"]').length,
          turnRoleUser: all('[data-turn="user"]').length,
          turnRoleAssistant: all('[data-turn="assistant"]').length,
          dataTurnRoleUser: all('[data-turn-role="user"]').length,
          dataTurnRoleAssistant: all('[data-turn-role="assistant"]').length,
          searchUserUnits: all(SEARCH_USER_MESSAGES).length,
          searchAssistantUnits: all(SEARCH_ASSISTANT_MESSAGES).length,
        },
        pageStructure: pageStructure(),
      };
    }

    function pageStructure() {
      const view = document.defaultView;
      let isTopFrame = false;
      try { isTopFrame = !!view && view.top === view; } catch (_) { /* Cross-origin parent details are not inspected. */ }
      let scannedElements = 0;
      let openShadowHosts = 0;
      let shadowScanTruncated = false;
      if (document.documentElement) {
        const walker = document.createTreeWalker(document.documentElement, 1);
        let element = walker.currentNode;
        while (element && scannedElements < 2000) {
          scannedElements++;
          if (element.shadowRoot) openShadowHosts++;
          element = walker.nextNode();
        }
        shadowScanTruncated = !!element;
      }
      return {
        documentIsCurrent: !!view && view.document === document,
        isTopFrame, bodyConnected: !!document.body?.isConnected,
        mainCount: all('main, [role="main"]').length,
        logCount: all('[role="log"]').length,
        feedCount: all('[role="feed"]').length,
        roleArticleCount: all('[role="article"]').length,
        markdownCount: all('.markdown').length,
        messageContentCount: all('[data-message-content]').length,
        workspaceTurns: all('[data-talvt-turn-state]').length,
        completedWorkspaceTurns: all('[data-talvt-turn-state="complete"]').length,
        workspaceUserUnits: all(SEARCH_USER_MESSAGES).length,
        workspaceAssistantUnits: all(SEARCH_ASSISTANT_MESSAGES).length,
        textFlowCount: all('[data-d-text-flow]').length,
        streamWordCount: all('[data-d-stream-word]').length,
        iframeCount: all('iframe').length,
        openShadowHosts, scannedElements, shadowScanTruncated,
      };
    }

    function requireRequest(requestId) {
      const request = requests.get(requestId);
      if (!request) throw new AdapterError("REQUEST_NOT_FOUND", "This ChatGPT page no longer knows this request. The tab may have reloaded. Check the conversation before starting another request.");
      return request;
    }

    function assertNotCancelled(request) {
      if (request.cancelled) throw new AdapterError("CANCELLED", "The operation was stopped.");
    }

    function currentPath() {
      return document.defaultView?.location?.pathname || null;
    }

    function conversationIdentity(path = currentPath()) {
      // ChatGPT can canonicalize /g/.../c/id to /c/id, or add/remove a trailing
      // slash, without changing the conversation. The ID is the boundary.
      const id = /(?:^|\/)c\/([^/]+)(?:\/|$)/u.exec(path || "")?.[1];
      return id && id !== "new" ? id : null;
    }

    function normalizedPath(path) {
      return String(path || "/").replace(/\/+$/u, "") || "/";
    }

    function conversationChanged() {
      throw new AdapterError("PAGE_CHANGED", "The ChatGPT tab switched conversations. Return to the submitted chunk's conversation before retrying. The prompt has not been resent.");
    }

    function ownsCompletedRouteHandoff(request, identity) {
      if (request.initialConversation || !identity || request.phase !== "complete" || request.completedRouteHandoff ||
          !request.routeCandidate || now() > request.routeCandidate.deadline) return false;
      const { user, reply } = requestTurns(request);
      return !!(user && reply && user.key === request.routeCandidate.userKey && user.node === request.routeCandidate.userNode &&
        reply.key === request.reply?.key && normalize(reply.text) === normalize(request.renderedReplyText) && !replyCompletion(reply).completionBlocked);
    }

    function assertConversation(request) {
      const identity = conversationIdentity();
      if (request.boundConversation && identity !== request.boundConversation && !ownsCompletedRouteHandoff(request, identity)) conversationChanged();
      if (!request.boundConversation && !identity && normalizedPath(currentPath()) !== normalizedPath(request.initialPath)) conversationChanged();
      if (!request.boundConversation && request.routeCandidate && identity !== request.routeCandidate.identity) {
        if (now() > request.routeCandidate.deadline) conversationChanged();
        const current = messages();
        // Empty DOM can be a route handoff. A different visible user turn is
        // positive evidence of a different conversation, never an alias.
        if (!requestTurns(request, current).user && current.some((message) => message.role === "user" && !request.baselineKeys.has(message.key))) conversationChanged();
      }
    }

    function assertSubmissionPage(request) {
      if (request.continueFrom && !requestStatus({requestId: request.continueFrom}).canContinue) {
        throw new AdapterError('PAGE_CHANGED', 'The conversation changed while preparing the follow-up. Nothing was sent.');
      }
      const initialIdentity = conversationIdentity(request.initialPath);
      if (initialIdentity ? conversationIdentity() !== initialIdentity : normalizedPath(currentPath()) !== normalizedPath(request.initialPath)) {
        throw new AdapterError("PAGE_CHANGED", "The ChatGPT tab switched conversations before Send. The prompt was not sent; return to the intended conversation before retrying.");
      }
    }

    function matchesSubmittedUser(request, message) {
      if (message.role !== 'user' || request.baselineKeys.has(message.key)) return false;
      const text = normalize(message.text);
      if (text === normalize(request.prompt)) return true;
      // Markdown rendering changes backslashes, entities and code formatting
      // in the displayed prompt. The bridge's fresh, opaque tag survives that
      // rendering and binds only this new user turn, never an arbitrary reply.
      return !!request.trackingTag && text.startsWith(`Request tracking ID: ${request.trackingTag} `);
    }

    function requestTurns(request, current = messages()) {
      // Bind the new user by the exact wire text or its fresh transport tag.
      // A later assistant/copy control alone never establishes request ownership.
      const users = current.filter((message) => matchesSubmittedUser(request, message))
        .filter((message, index, matches) => matches.findIndex(candidate => candidate.key === message.key) === index);
      if (users.length > 1) throw new AdapterError('REQUEST_AMBIGUOUS', 'More than one new user turn has this request identity. Inspect the conversation; nothing will be resent.');
      const user = users[0];
      if (!user) return { user: null, reply: null };
      const reply = current.find((message) => message.role === "assistant" && message.index > user.index &&
        !request.baselineKeys.has(message.key));
      return { user, reply: reply || null };
    }

    function currentReply(request) {
      assertConversation(request);
      // Long prompts can be replaced by a short prefix until Show more is
      // clicked. Expand only a unique new candidate, then still require the
      // complete exact prompt match below before binding any assistant reply.
      const current = messages();
      if (!request.cancelled && !current.some(message => matchesSubmittedUser(request, message))) {
        const candidates = current.filter(message => message.role === 'user' && !request.baselineKeys.has(message.key));
        if (candidates.length === 1) {
          const candidate = candidates[0];
          const prefix = normalize(candidate.text);
          const expand = buttons(candidate.unit || candidate.node).filter(button => enabled(button) && exact(label(button), /^show more$/iu));
          request.expandedUserNodes ||= new WeakSet();
          if (prefix.length >= 80 && normalize(request.prompt).startsWith(prefix) && expand.length === 1 &&
              !request.expandedUserNodes.has(candidate.node)) {
            request.expandedUserNodes.add(candidate.node);
            expand[0].click();
          }
        }
      }
      const { user, reply } = requestTurns(request);
      if (!user) return null;
      // A new chat can render its user turn before receiving its permanent
      // route, and can briefly use an optimistic ID. Do not bind the first URL
      // sampled during generation. A replacement is allowed only while the
      // same exact new user turn remains present, before accepting the reply,
      // and within ten seconds of the first candidate route.
      const identity = conversationIdentity();
      request.routeReady = true;
      if (request.boundConversation && identity !== request.boundConversation) {
        // A fast completed reply can precede canonical URL assignment. One
        // final handoff is safe only with the same
        // owned user node and the entire already-verified completed reply.
        request.completedRouteHandoff = true;
        request.boundConversation = identity;
        request.routeCandidate = { ...request.routeCandidate, identity };
      }
      if (!request.boundConversation && identity) {
        const previous = request.routeCandidate;
        if (previous && previous.identity !== identity) {
          if (request.phase === "complete" || now() > previous.deadline || previous.userKey !== user.key || previous.userNode !== user.node) conversationChanged();
        }
        if (!previous || previous.identity !== identity) {
          request.routeCandidate = { identity, since: now(), deadline: previous?.deadline ?? now() + 10000, userKey: user.key, userNode: user.node };
        }
        request.routeReady = now() - request.routeCandidate.since >= 1200;
        // A reply accepted on a route-less temporary/new-chat screen may
        // receive its first permanent URL later. Its exact owned turn still
        // has to be present; subsequent conversation changes remain blocked.
        if (request.phase === "complete") request.boundConversation = identity;
      } else if (!request.boundConversation && request.routeCandidate) {
        conversationChanged();
      }
      request.userKey = user.key;
      if (reply) request.reply = reply;
      return reply || null;
    }

    async function waitUntil(getValue, timeoutMs, request) {
      const deadline = now() + timeoutMs;
      do {
        if (request) assertNotCancelled(request);
        const result = getValue();
        if (result) return result;
        await sleep(200);
      } while (now() < deadline);
      return null;
    }

    function composerValue(composer) {
      if ("value" in composer) return composer.value;
      // The rich editor hydrates plain text into paragraphs/BRs. innerText
      // depends on layout, while textContent joins adjacent lines together.
      // Read logical line boundaries so focusing/re-rendering the editor does
      // not turn an unchanged multiline request into a different prompt.
      const read = node => {
        if (node.nodeType === 3) return node.textContent || '';
        if (node.nodeType !== 1) return '';
        if (node.tagName === 'BR') return '\n';
        const text = Array.from(node.childNodes, read).join('');
        return /^(?:P|DIV|LI|PRE|BLOCKQUOTE|H[1-6])$/u.test(node.tagName) ? `\n${text}\n` : text;
      };
      return Array.from(composer.childNodes, read).join('');
    }

    function dispatchInput(composer, text) {
      const ViewInputEvent = document.defaultView.InputEvent || document.defaultView.Event;
      composer.dispatchEvent(new ViewInputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
    }

    function fillComposer(composer, prompt) {
      composer.focus();
      if ("value" in composer) {
        const prototype = Object.getPrototypeOf(composer);
        const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
        if (setter) setter.call(composer, prompt);
        else composer.value = prompt;
        dispatchInput(composer, prompt);
      } else {
        const selection = document.getSelection && document.getSelection();
        if (selection && document.createRange && document.execCommand) {
          const range = document.createRange();
          range.selectNodeContents(composer);
          selection.removeAllRanges();
          selection.addRange(range);
          if (!document.execCommand("insertText", false, prompt)) {
            composer.textContent = prompt;
            dispatchInput(composer, prompt);
          }
          selection.removeAllRanges();
        } else {
          composer.textContent = prompt;
          dispatchInput(composer, prompt);
        }
      }
      if (normalize(composerValue(composer)) !== normalize(prompt)) {
        throw new AdapterError("COMPOSER_WRITE_FAILED", "ChatGPT's text box did not accept the complete prompt. Check the draft in the tab before trying again.");
      }
    }

    function findSendControl(composer) {
      const scope = composerScope(composer);
      if (!scope) return null;
      const eligible = (button) => visible(button) && enabled(button)
        && !button.closest(`${MESSAGE_CONTAINERS}, ${AUTHOR_MESSAGES}, [role="menu"]`)
        && button.closest('[role="dialog"]') === composer.closest('[role="dialog"]');
      const known = all(SEND_CONTROL, scope).find(eligible);
      if (known) return known;
      const labelled = buttons(scope).find((button) => eligible(button) && exact(label(button), /^send(?: prompt| message)?$/i));
      if (labelled) return labelled;
      // A renamed icon-only Send can still be the native submit button. Limit
      // this fallback to one unambiguous control in the verified editor's form.
      const form = composer.matches(MODERN_COMPOSER) && composer.closest('form');
      if (!form) return null;
      const submitters = all('button[type="submit"]', form).filter((button) =>
        button.form === form && eligible(button) && !/voice|audio|dictat|record|transcri/i.test(label(button)));
      return submitters.length === 1 ? submitters[0] : null;
    }

    function clearOwnedDraft(request) {
      if (request.sendClicked || !request.composer || !document.contains(request.composer)) return;
      if (normalize(composerValue(request.composer)) !== normalize(request.prompt)) return;
      try { fillComposer(request.composer, ""); } catch (_) { /* Never replace a draft that the page refused to clear. */ }
    }

    function attachmentPresent(request) {
      const scope = composerScope(request.composer);
      return !!scope && normalize(scope.textContent).includes(request.attachmentName) && hasAttachments(request.composer);
    }

    function assertFileUploadAvailable() {
      // ChatGPT's account quota panel is a plain heading near the composer,
      // not necessarily an alert, and may already be visible before upload.
      const limit = /you['’]ve reached the limit for file attachments|file (?:upload|attachment) limit (?:reached|exceeded)/iu;
      const notice = all('h1, h2, h3, h4, h5, h6, [role="heading"], [role="alert"]').find(element =>
        visible(element) && !element.closest(`${MESSAGE_CONTAINERS}, ${ROLE_MESSAGES}`) && limit.test(normalize(element.textContent)));
      if (!notice) return;
      const copy = (notice.matches('[role="alert"]') ? notice : notice.parentElement || notice).cloneNode(true);
      for (const control of all('button, [role="button"]', copy)) control.remove();
      for (const block of all('h1, h2, h3, h4, h5, h6, p', copy)) block.append(' ');
      throw new AdapterError('UPLOAD_LIMIT', `ChatGPT cannot accept file attachments right now. ${normalize(copy.textContent).slice(0, 800)} Nothing was sent.`);
    }

    function textFileInput(input) {
      const accept = (input.getAttribute('accept') || '').toLowerCase();
      return !input.disabled && (!accept || accept.split(',').some(type => /^(?:\.txt|text\/\*|text\/plain|\*\/\*)$/u.test(type.trim())));
    }

    async function prepareFileInput(request) {
      const scope = composerScope(request.composer);
      const menuButton = buttons(scope).filter(button => enabled(button) &&
        exact(label(button), /^(?:add files and more|add files|attach files|add photos and files)$/iu));
      // Current ChatGPT associates a selection request with the upload menu.
      // Changing files directly skips that lifecycle and can be silently ignored.
      if (menuButton.length === 1) {
        menuButton[0].click();
        const uploadLabel = /^(?:(?:add|upload|attach) (?:photos\s*(?:&|and)\s*)?files|upload from computer)(?:\b|$)/iu;
        const choice = await waitUntil(() => {
          assertFileUploadAvailable();
          return buttons().find(button => enabled(button) && button !== menuButton[0] &&
            (uploadLabel.test(normalize(label(button))) || uploadLabel.test(normalize(button.textContent))));
        }, 5000, request);
        if (!choice) {
          // Menu wording and availability vary by account. File paste uses the
          // same File and still requires the named, completed attachment chip.
          const target = document.activeElement || menuButton[0];
          target.dispatchEvent(new document.defaultView.KeyboardEvent('keydown', {key: 'Escape', code: 'Escape', bubbles: true}));
          return null;
        }
        let selected = null;
        // Let the page initialize its normal selection lifecycle, while
        // cancelling only the native dialog: the extension already owns the File.
        const intercept = event => {
          if (event.target?.matches?.('input[type="file"]')) {
            event.preventDefault();
            selected = event.target;
          }
        };
        document.addEventListener('click', intercept, true);
        try {
          choice.click();
          await waitUntil(() => { assertFileUploadAvailable(); return selected; }, 2000, request);
        } finally { document.removeEventListener('click', intercept, true); }
        if (!selected || !textFileInput(selected)) throw new AdapterError('UPLOAD_UNAVAILABLE', 'ChatGPT did not open a text-capable file input. Check its upload controls; nothing was sent.');
        return selected;
      }
      // Older layouts can expose a direct file input without the menu lifecycle.
      const inputs = all('input[type="file"]').filter(textFileInput);
      const scoped = inputs.filter(input => scope?.contains(input));
      const candidates = scoped.length ? scoped : inputs;
      return candidates.length === 1 ? candidates[0] : null;
    }

    async function attachRequestFile(request) {
      assertFileUploadAvailable();
      const view = document.defaultView;
      if (!view.File || !view.DataTransfer) throw new AdapterError('UPLOAD_UNAVAILABLE', 'This browser cannot prepare a text attachment. Use the manual file upload controls.');
      const file = new view.File([request.sourcePrompt], request.attachmentName, {type: 'text/plain'});
      const transfer = new view.DataTransfer();
      transfer.items.add(file);
      const input = await prepareFileInput(request);
      assertNotCancelled(request);
      assertSubmissionPage(request);
      try {
        if (input) {
          input.files = transfer.files;
          input.dispatchEvent(new view.Event('input', {bubbles: true}));
          input.dispatchEvent(new view.Event('change', {bubbles: true}));
        } else {
          if (!view.ClipboardEvent) throw new Error('No file upload input or file paste event is available.');
          request.composer.dispatchEvent(new view.ClipboardEvent('paste', {clipboardData: transfer, bubbles: true, cancelable: true}));
        }
      } catch (_) {
        throw new AdapterError('UPLOAD_UNAVAILABLE', 'ChatGPT did not accept the prepared text file. Check its attachment controls; nothing was sent.');
      }
      const deadline = now() + 90000;
      while (now() < deadline) {
        assertNotCancelled(request);
        assertSubmissionPage(request);
        if (normalize(composerValue(request.composer))) throw new AdapterError('COMPOSER_CHANGED', 'The draft changed while the file was uploading. Nothing was sent.');
        const scope = composerScope(request.composer);
        assertFileUploadAvailable();
        const errors = all('[role="alert"]').filter(visible).filter(element => request.uploadBaselineAlerts.get(element) !== normalize(element.textContent));
        if (errors.some(element => /fail|error|unable|limit|too (?:large|many)|not supported|unsupported/iu.test(element.textContent || ''))) {
          throw new AdapterError('UPLOAD_FAILED', 'ChatGPT could not upload the text file. Check its upload notice; nothing was sent.');
        }
        const loading = all('[role="progressbar"], [aria-busy="true"], [data-state="uploading"], .animate-spin', scope).some(visible)
          || /\b(?:uploading|processing file)\b/iu.test(scope.textContent || '');
        if (attachmentPresent(request) && !loading) return;
        await sleep(200);
      }
      throw new AdapterError('UPLOAD_TIMEOUT', 'The text file did not finish uploading. Check ChatGPT; nothing was sent.');
    }

    async function performSubmit(request) {
      try {
        if (generationButton()) throw new AdapterError("GENERATION_BUSY", "ChatGPT is already generating a reply. Wait for it to finish before submitting this chunk.", true);
        assertChatMemoryAvailable();
        const composer = await waitUntil(() => composerSelection().editable[0], 5000, request) || composerSelection().editable[0];
        assertNotCancelled(request);
        assertSubmissionPage(request);
        if (!composer) {
          const state = readiness();
          throw new AdapterError(state.readinessCode, state.readinessMessage, true);
        }
        if (generationButton(composer)) throw new AdapterError("GENERATION_BUSY", "ChatGPT is already generating a reply. Wait for it to finish before submitting this chunk.", true);
        if (normalize(composerValue(composer))) throw new AdapterError("COMPOSER_NOT_EMPTY", "The ChatGPT text box already contains a draft. Send or clear that draft in the tab before starting.");
        if (hasAttachments(composer)) {
          throw new AdapterError("ATTACHMENTS_PRESENT", "Remove the existing attachment from ChatGPT before starting this text request.");
        }
        request.baselineKeys = new Set(messages().map((message) => message.key));
        request.composer = composer;
        if (request.delivery === 'attachment') {
          request.uploadBaselineAlerts = new Map(all('[role="alert"]').map(element => [element, normalize(element.textContent)]));
          await attachRequestFile(request);
        }
        fillComposer(composer, request.prompt);
        const expected = normalize(request.prompt);
        let stableSince = null;
        let stableComposer = null;
        let draftMismatch = false;
        const sent = await waitUntil(() => {
          assertSubmissionPage(request);
          assertChatMemoryAvailable();
          const current = composerSelection().editable[0];
          draftMismatch = !current || normalize(composerValue(current)) !== expected;
          if (draftMismatch) { stableSince = null; stableComposer = null; return false; }
          request.composer = current;
          if (request.delivery !== 'attachment' && hasAttachments(current)) throw new AdapterError('ATTACHMENTS_PRESENT', 'ChatGPT added an attachment to this text request. Nothing was sent.');
          const send = findSendControl(current);
          if (!send) { stableSince = null; stableComposer = null; return false; }
          if (stableSince === null || stableComposer !== current) { stableSince = now(); stableComposer = current; return false; }
          if (now() - stableSince < 200) return false;
          if (request.delivery === 'attachment' && (!attachmentPresent(request) || attachmentRemoveButtons(current).length !== 1)) {
            throw new AdapterError('ATTACHMENT_CHANGED', 'The prepared attachment changed before sending. Nothing was sent.');
          }
          // Verify and click in the same turn, after editor hydration settles.
          // Never refill a changed draft or retry a possibly completed Send.
          request.sendClicked = true;
          request.phase = "submitted";
          request.submittedAt = now();
          watchRateLimit(request);
          try { send.click(); }
          catch (_) { throw new AdapterError("SEND_UNCERTAIN", "The Send action may have reached ChatGPT. Check the conversation before starting a new request."); }
          return true;
        }, 5000, request);
        if (!sent) {
          if (draftMismatch) throw new AdapterError('COMPOSER_CHANGED', "ChatGPT's editor no longer matches the prepared prompt. Nothing was sent.");
          throw new AdapterError("SEND_NOT_FOUND", "ChatGPT's Send button is missing or disabled. Your draft is still in the tab; check it before retrying.", true);
        }
        return { ok: true, requestId: request.id, documentToken, phase: request.phase, baselineCount: request.baselineKeys.size };
      } catch (error) {
        if (request.cancelled || ['PAGE_CHANGED','CHAT_MEMORY_FULL'].includes(error.code)) clearOwnedDraft(request);
        request.submitError = error;
        if (!request.sendClicked) request.phase = "failed";
        throw error;
      }
    }

    async function submit(message) {
      if (message.expectedDocumentToken && message.expectedDocumentToken !== documentToken) {
        throw new AdapterError("PAGE_CHANGED", "The ChatGPT tab reloaded or navigated. Check whether your previous prompt was sent before starting another request.");
      }
      if (typeof message.requestId !== "string" || !message.requestId || message.requestId.length > 200) {
        throw new AdapterError("INVALID_REQUEST", "A unique requestId is required.");
      }
      if (typeof message.text !== "string" || !message.text.trim() || message.text.length > MAX_TEXT_LENGTH) {
        throw new AdapterError("INVALID_TEXT", "Provide a nonempty prompt of at most 2,200,000 characters.");
      }
      const sourcePrompt = typeof message.prompt === "string" && message.prompt.trim() ? message.prompt : message.text;
      if (sourcePrompt.length > MAX_TEXT_LENGTH) throw new AdapterError("INVALID_TEXT", "The prompt exceeds 2,200,000 characters.");
      const delivery = message.delivery || 'text';
      if (!['text', 'attachment'].includes(delivery)) throw new AdapterError('INVALID_DELIVERY', 'Choose text or attachment delivery.');
      const attachmentName = `bridge-request-${message.requestId.replace(/[^a-zA-Z0-9_-]/gu, '_').slice(0, 80)}.txt`;
      const trackRequest = message.trackRequest === true && delivery === 'text';
      const existing = requests.get(message.requestId);
      const trackingTag = existing?.trackingTag || (trackRequest ? `CVBRIDGE-${document.defaultView.crypto.randomUUID()}` : null);
      const prompt = delivery === 'attachment'
        ? `Read the attached ${attachmentName} as the task request I prepared. Complete the task using its supplied reference data and follow its instructions, privacy rules and output format. Return only the requested result.`
        : trackingTag ? `Request tracking ID: ${trackingTag} (transport only; omit from the response).\n\n${sourcePrompt}` : sourcePrompt;
      if (prompt.length > MAX_TEXT_LENGTH) throw new AdapterError('INVALID_TEXT', 'The prompt and its request tracking line exceed 2,200,000 characters.');
      const format = message.format || "text";
      if (!["text", "json", "latex"].includes(format)) throw new AdapterError("INVALID_FORMAT", "Choose text, json or latex output.");
      if (existing) {
        if (existing.text !== message.text || existing.sourcePrompt !== sourcePrompt || existing.delivery !== delivery || existing.format !== format || existing.continueFrom !== message.continueFrom || existing.trackRequest !== trackRequest) throw new AdapterError("REQUEST_CONFLICT", "This requestId was already used for different text. Use a new requestId.");
        return existing.submitPromise;
      }
      if (message.continueFrom && !requestStatus({requestId: message.continueFrom}).canContinue) {
        throw new AdapterError('PAGE_CHANGED', 'The previous request is no longer the latest completed reply in this conversation. Nothing was sent.');
      }
      const inFlight = Array.from(requests.values()).find((request) => !request.cancelled && ["preparing", "submitted"].includes(request.phase));
      if (inFlight) throw new AdapterError("REQUEST_BUSY", "This tab already has an unfinished chunk. Finish or stop it before submitting another.");
      const path = currentPath();
      const initialConversation = conversationIdentity(path);
      const request = { id: message.requestId, text: message.text, sourcePrompt, prompt, delivery, attachmentName, format, trackRequest, trackingTag, continueFrom: message.continueFrom, phase: "preparing", createdAt: now(), cancelled: false, sendClicked: false, baselineKeys: new Set(), initialPath: path, initialConversation, boundConversation: initialConversation };
      requests.set(request.id, request);
      request.submitPromise = performSubmit(request);
      return request.submitPromise;
    }

    function replyCompletion(reply) {
      const turnState = reply?.turnStateNode?.getAttribute('data-talvt-turn-state') || null;
      const generating = !!generationButton() || !!(reply && reply.article.querySelector('[data-is-streaming="true"], .result-streaming')) || /^(?:running|generating|streaming|pending)$/iu.test(turnState || '');
      const completionBlocked = generating || !!reply?.requiresTurnCompletion && turnState !== 'complete';
      return { generating, completionBlocked, turnState };
    }

    async function performWait(request, timeoutMs) {
      await request.submitPromise;
      const deadline = now() + timeoutMs;
      let stableText = request.replyObservation?.signature || "";
      let stableSince = request.replyObservation?.stableSince ?? now();
      while (now() < deadline) {
        assertNotCancelled(request);
        assertConversation(request);
        const reply = currentReply(request);
        assertNotRateLimited(request,reply);
        const text = reply ? reply.text : "";
        const signature = reply ? JSON.stringify([reply.key, text, codeBlocksFor(reply)]) : "";
        if (signature !== stableText || !text.trim()) {
          stableText = signature;
          stableSince = now();
        }
        const { completionBlocked: streaming } = replyCompletion(reply);
        if (!streaming && request.replyObservation?.streaming) stableSince = now();
        if (streaming) {
          request.generationSeen = true;
          stableSince = now();
        }
        const responseCopy = reply && all('[data-testid="copy-turn-action-button"], button[aria-label="Copy"], button[aria-label="Copy response"]', reply.actionRoot).some(visible);
        const completedCodeCopy = reply && replyCompletion(reply).turnState === 'complete' && all('button[aria-label="Copy code"]', reply.unit || reply.node).some(visible);
        const readyAction = responseCopy || completedCodeCopy;
        // Rendered text may pause mid-stream. Completed message actions provide
        // stronger evidence; unfamiliar layouts get a longer stable interval.
        const stableFor = readyAction ? 1200 : 2500;
        request.replyObservation = { key: reply?.key || null, text, signature, stableSince, streaming, stableFor };
        if (reply && text.trim() && !streaming && request.routeReady !== false && now() - stableSince >= stableFor) {
          if (request.routeCandidate) request.boundConversation = request.routeCandidate.identity;
          const result = responseFor(request, reply);
          request.phase = "complete";
          request.retryInProgress=false;request.limitWatch?.observer?.disconnect();
          request.renderedReplyText = text;
          request.replyText = result.text;
          request.replyCodeBlocks = result.codeBlocks;
          return { ok: true, requestId: request.id, ...result, turnId: reply.turnId, documentToken };
        }
        if(chatMemoryFull() && !streaming && (!text.trim() || now()-stableSince>=stableFor))assertChatMemoryAvailable();
        await sleep(200);
      }
      throw new AdapterError("REPLY_TIMEOUT", "A completed reply to this chunk was not found in time. Check ChatGPT for a sign-in prompt, limit message, or an unfinished response. The prompt has not been resent.", true);
    }

    async function waitForReply(message) {
      const request = requireRequest(message.requestId);
      assertNotCancelled(request);
      if (request.replyText !== undefined) return { ok: true, requestId: request.id, text: request.replyText, codeBlocks: request.replyCodeBlocks || [], turnId: request.reply?.turnId || null, documentToken };
      if (!request.waitPromise) {
        const timeoutMs = Math.max(1000, Math.min(Number(message.timeoutMs) || 120000, 180000));
        request.waitPromise = performWait(request, timeoutMs).finally(() => { request.waitPromise = null; });
      }
      return request.waitPromise;
    }

    async function retryRateLimited(message) {
      const request=requireRequest(message.requestId);
      assertNotCancelled(request);assertConversation(request);
      if(request.retryPromise)return request.retryPromise;
      if(!request.rateLimited)throw new AdapterError('RETRY_NOT_ALLOWED','Only a confirmed message-limit failure can be retried automatically.');
      request.retryPromise=(async()=>{
        const current=messages(),{user,reply}=requestTurns(request,current);
        const latestUser=current.filter(item=>item.role==='user').at(-1);
        if(latestUser && latestUser.key!==user?.key && !request.baselineKeys.has(latestUser.key))conversationChanged();
        const alert=rateLimitAlert();
        const retry=alert && buttons(alert).find(button=>enabled(button) && exact(label(button),/^retry$/iu));
        if(reply?.text.trim()) {
          request.phase='submitted';request.rateLimited=false;request.replyObservation=null;
          return {ok:true,requestId:request.id,documentToken,phase:request.phase,attempted:false,method:'observe'};
        }
        if(alert && buttons(alert).some(button=>exact(label(button),/^retry$/iu)) && !retry) {
          throw new AdapterError('RETRY_NOT_READY','No new request was sent: ChatGPT’s Retry control is still disabled. Checking again without increasing the backoff.',true);
        }
        request.rateLimitRetryAt=now();
        request.retryInProgress=true;
        if(retry) {
          watchRateLimit(request);
          retry.click();request.phase='submitted';request.submittedAt=now();
        } else {
          // A confirmed rejected request can be submitted again if ChatGPT no
          // longer offers Retry. Clear only the draft owned by this request.
          clearOwnedDraft(request);request.phase='preparing';request.sendClicked=false;
          request.submitPromise=performSubmit(request);await request.submitPromise;
        }
        request.rateLimited=false;request.replyObservation=null;
        return {ok:true,requestId:request.id,documentToken,phase:request.phase,attempted:true,method:retry?'retry':'submit'};
      })().finally(()=>{request.retryPromise=null;});
      return request.retryPromise;
    }

    function requestStatus(message) {
      const current = messages();
      const counts = messageDiagnostics(current);
      const request = requests.get(message.requestId);
      if (!request) return {
        ok: false, requestId: message.requestId || null, documentToken,
        requestFound: false, phase: "unknown", waitingFor: "request", ...counts,
        error: { code: "REQUEST_NOT_FOUND", message: "This ChatGPT page no longer knows this request. The tab may have reloaded. Check the conversation before retrying.", retryable: false },
      };
      assertConversation(request);
      // This is observation only. It cannot submit, change the bound reply,
      // advance its stability timer, or accept text as a completed reply.
      const { user, reply } = requestTurns(request, current);
      const { generating, completionBlocked, turnState } = replyCompletion(reply);
      const observation = request.replyObservation;
      const observedSameReply = reply && observation?.key === reply.key && observation.text === reply.text;
      const replyStableForMs = observedSameReply && !completionBlocked && !observation.streaming
        ? Math.max(0, now() - observation.stableSince) : 0;
      const replyReady = request.replyText !== undefined;
      const waitingFor = request.cancelled ? "stopped"
        : request.phase === "failed" ? "submission"
        : !request.sendClicked ? "submission"
        : !user ? "user-turn"
        : !reply ? "assistant-reply"
        : generating ? "generation"
        : replyReady ? "verified-reply" : "completion";
      return {
        ok: true, requestId: request.id, documentToken,
        phase: request.cancelled ? "stopped" : request.phase,
        requestFound: true, sendClicked: request.sendClicked,
        userTurnFound: !!user, replyFound: !!reply, recognizedReply: !!reply,
        userMatchMethod: user ? (normalize(user.text) === normalize(request.prompt) ? 'exact-text' : 'request-tag') : null,
        replyCharacters: reply?.text.length || 0, replyReady, generating,
        canContinue: !request.cancelled && request.phase === 'complete' && replyReady && !completionBlocked && !!user && !!reply && current.at(-1)?.key === reply.key,
        replyTurnState: turnState, completionBlocked,
        replyStableForMs, replyStableRequiredMs: observation?.stableFor || 0,
        elapsedMs: Math.max(0, now() - (request.submittedAt ?? request.createdAt)),
        waitingFor, ...counts,
      };
    }

    async function stop(message) {
      const targets = message.requestId ? [requireRequest(message.requestId)] : Array.from(requests.values());
      for (const request of targets) {
        request.cancelled = true;
        request.limitWatch?.observer?.disconnect();
        clearOwnedDraft(request);

      }
      if (message.stopGeneration === true) {
        // Never stop a different conversation or a later user-owned turn.
        for (const request of targets) {
          try {
            assertConversation(request);
            const current = messages();
            const user = requestTurns(request, current).user;
            if (user && current.filter(turn => turn.role === 'user').at(-1)?.key === user.key) generationButton()?.click();
          } catch (_) { /* A moved page must keep its own generation. */ }
        }
      }
      return { ok: true, requestId: message.requestId || null, stopped: true };
    }

    async function dispatch(message) {
      try {
        switch (message.action) {
          case "probe": return { ok: true, adapterVersion: ADAPTER_VERSION, adapterBuildId: BUILD_ID, documentToken, adapterBusy:Array.from(requests.values()).some(request=>!request.cancelled && (['preparing','submitted','rate-limited'].includes(request.phase) || request.waitPromise)), ...readiness(), ...messageDiagnostics() };
          case "submit": return await submit(message);
          case "waitForReply": return await waitForReply(message);
          case "retryRateLimited": return await retryRateLimited(message);
          case "requestStatus": return requestStatus(message);
          case "stop": return await stop(message);
          default: throw new AdapterError("UNKNOWN_ACTION", "The requested ChatGPT page action is not supported.");
        }
      } catch (error) {
        return { ok: false, requestId: message.requestId || null, documentToken, error: { code: error.code || "PAGE_ERROR", message: error.message || "The ChatGPT page could not complete this action.", retryable: !!error.retryable } };
      }
    }

    return { dispatch, documentToken, dispose() {
      for(const request of requests.values())request.limitWatch?.observer?.disconnect();
    } };
  }

  // The isolated test VM supplies this hook. Avoid CommonJS syntax here: a
  // browser bundler would otherwise wrap this classic content script as a module.
  if (global.__CHATGPT_BRIDGE_TEST_EXPORT__) {
    Object.assign(global.__CHATGPT_BRIDGE_TEST_EXPORT__, { createAdapter, normalize });
    return;
  }
  if (!global.chrome?.runtime?.onMessage) return;
  const prior = global.__chatgptBrowserBridgeInstalled;
  // Very old adapters did not expose their listener for disposal. Their probe
  // triggers the explicit one-time tab refresh instead of installing two.
  if (prior === true) return;
  if (prior?.version === ADAPTER_VERSION && prior?.buildId === BUILD_ID) return;
  if (prior?.listener) {
    global.chrome.runtime.onMessage.removeListener(prior.listener);
    prior.adapter?.dispose();
  }
  const adapter = createAdapter(global.document);
  const listener = (message, _sender, sendResponse) => {
    if (!message || message.target !== TARGET) return false;
    adapter.dispatch(message).then(sendResponse, () => sendResponse({ ok: false, error: { code: "PAGE_ERROR", message: "The ChatGPT page action failed.", retryable: false } }));
    return true;
  };
  global.__chatgptBrowserBridgeInstalled = { version: ADAPTER_VERSION, buildId: BUILD_ID, listener, adapter };
  global.chrome.runtime.onMessage.addListener(listener);
})(globalThis);
